"""
    Asguard Addon
    Copyright (C) 2026
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import logging
import re
import json
import urllib.parse
import requests
from asguard_lib.utils2 import i18n
import xbmcgui
import kodi
import log_utils
from asguard_lib import scraper_utils, control
from asguard_lib.constants import VIDEO_TYPES, QUALITIES, FORCE_NO_MATCH
from . import scraper


try:
    import resolveurl
except ImportError:
    kodi.notify(msg=i18n('smu_failed'), duration=5000)

logger = log_utils.Logger.get_logger()

class Scraper(scraper.Scraper):
    base_url = 'https://mediafusion.elfhosted.com'
    debrid_resolvers = resolveurl

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting('%s-base_url' % (self.get_name()))
        self.min_seeders = 0
        self.bypass_filter = control.getSetting('Mediafusion-bypass_filter') == 'true'
        logger.log('MediaFusion: Initializing scraper', log_utils.LOGDEBUG)
        self._set_apikeys()
        self.headers = f'D-ho36tsmpCpWQwOabEKKoE7CwC4pAY3KBYtgqPo-9TImVifcfGczc-1JRsYQFxFlheByJh-1KGu1pVDz3iBFmYuCixEdXXYD6ZV0oM1la9KvMRfWAmlj9tASvKw6rE-eo'

        # Build dynamic configuration with user's API keys
        params = self._build_config_params()
        self.movie_search_url = f'/{self.headers}/stream/movie/%s.json'
        self.tv_search_url = f'/{self.headers}/stream/series/%s:%s:%s.json'
        logger.log('MediaFusion: Scraper initialized successfully', log_utils.LOGDEBUG)

    def _headers(self):
        headers = f'D-ho36tsmpCpWQwOabEKKoE7CwC4pAY3KBYtgqPo-9TImVifcfGczc-1JRsYQFxFlheByJh-1KGu1pVDz3iBFmYuCixEdXXYD6ZV0oM1la9KvMRfWAmlj9tASvKw6rE-eo'
        return headers

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'Mediafusion'

    def resolve_link(self, link):
        return link

    def _set_apikeys(self):
        self.pm_apikey = kodi.get_setting('premiumize.apikey')
        self.rd_apikey = kodi.get_setting('realdebrid.apikey')
        self.ad_apikey = kodi.get_setting('alldebrid_api_key')
        self.tb_apikey = kodi.get_setting('torbox.apikey')
        self.dl_apikey = kodi.get_setting('debridlink.apikey')

    def _build_config_params(self):
        """Build MediaFusion configuration parameters with user's debrid API keys"""
        import base64

        # Configuration matching MediaFusion's expected format
        config = {
            "maxResultsPerResolution": 0,
            "maxSize": 0,
            "cachedOnly": False,
            "removeTrash": True,
            "resultFormat": ["all"],
            "debridService": "alldebrid",  # Default to AllDebrid
            "debridApiKey": "",
            "debridStreamProxyPassword": "",
            "languages": {
                "required": [],
                "exclude": [],
                "preferred": []
            },
            "resolutions": {},
            "options": {
                "remove_ranks_under": -10000000000,
                "allow_english_in_languages": False,
                "remove_unknown_languages": False
            }
        }

        # Add debrid API key based on priority
        debrid_configured = False

        if self.rd_apikey:
            config["debridApiKey"] = self.rd_apikey
            config["debridService"] = "realdebrid"
            debrid_configured = True
            logger.log('MediaFusion: Using Real-Debrid API key', log_utils.LOGDEBUG)
        elif self.tb_apikey:
            config["debridApiKey"] = self.tb_apikey
            config["debridService"] = "torbox"
            debrid_configured = True
            logger.log('MediaFusion: Using TorBox API key', log_utils.LOGDEBUG)
        elif self.ad_apikey:
            config["debridApiKey"] = self.ad_apikey
            config["debridService"] = "alldebrid"
            debrid_configured = True
            logger.log('MediaFusion: Using AllDebrid API key', log_utils.LOGDEBUG)
        elif self.pm_apikey:
            config["debridApiKey"] = self.pm_apikey
            config["debridService"] = "premiumize"
            debrid_configured = True
            logger.log('MediaFusion: Using Premiumize API key', log_utils.LOGDEBUG)
        elif self.dl_apikey:
            config["debridApiKey"] = self.dl_apikey
            config["debridService"] = "debridlink"
            debrid_configured = True
            logger.log('MediaFusion: Using DebridLink API key', log_utils.LOGDEBUG)

        if not debrid_configured:
            # Fallback to default TorBox key
            config["debridApiKey"] = kodi.get_setting('torbox.apikey')
            config["debridService"] = "torbox"
            logger.log('MediaFusion: No user debrid API keys configured, using default TorBox key', log_utils.LOGWARNING)

        # Encode configuration to base64
        config_json = json.dumps(config, separators=(',', ':'))
        params = base64.b64encode(config_json.encode('utf-8')).decode('utf-8')

        logger.log('MediaFusion: Generated config for debrid service: %s' % config["debridService"], log_utils.LOGDEBUG)
        return params

    def get_sources(self, video):
        sources = []

        try:
            # Use centralized IMDB ID retrieval from base class
            imdb_id = self.get_imdb_id(video)
            if not imdb_id:
                logger.log('MediaFusion: No IMDB ID found for trakt_id: %s' % video.trakt_id, log_utils.LOGWARNING)
                return sources

            if video.video_type == VIDEO_TYPES.MOVIE:
                search_url = self.movie_search_url % imdb_id
                logger.log('MediaFusion: Searching for movie: %s' % search_url, log_utils.LOGDEBUG)
            elif video.video_type == VIDEO_TYPES.EPISODE:
                search_url = self.tv_search_url % (imdb_id, video.season, video.episode)
                logger.log('MediaFusion: Searching for episode: %s' % search_url, log_utils.LOGDEBUG)
            else:
                logger.log('MediaFusion: Unsupported video type: %s' % video.video_type, log_utils.LOGWARNING)
                return sources

            url = urllib.parse.urljoin(self.base_url, search_url)
            logger.log('MediaFusion: Request URL: %s' % url, log_utils.LOGDEBUG)

            response = self._http_get(url, cache_limit=1, require_debrid=True)
            if not response or response == FORCE_NO_MATCH:
                logger.log('MediaFusion: No response from server for URL: %s' % url, log_utils.LOGWARNING)
                return sources

            logger.log('MediaFusion: Received response length: %d characters' % len(response), log_utils.LOGDEBUG)

            if not response:
                return sources

            try:
                data = json.loads(response)
                files = data.get('streams', [])
                logger.log('MediaFusion: Found %d streams in response' % len(files), log_utils.LOGDEBUG)

                if not files:
                    logger.log('MediaFusion: No streams found. Response keys: %s' % list(data.keys()), log_utils.LOGDEBUG)
                    if 'error' in data:
                        logger.log('MediaFusion: API error: %s' % data['error'], log_utils.LOGWARNING)

            except json.JSONDecodeError as e:
                logger.log('MediaFusion: Failed to parse JSON response: %s' % str(e), log_utils.LOGERROR)
                logger.log('MediaFusion: Response content: %s' % response[:500], log_utils.LOGDEBUG)
                return sources

            for file in files:
                try:
                    # Try multiple ways to get the filename and description
                    name = ''
                    description = ''

                    # Method 1: behaviorHints.filename (newer format)
                    if 'behaviorHints' in file and 'filename' in file['behaviorHints']:
                        name = file['behaviorHints']['filename'].split('\n')[0]
                        description = file.get('description', '')
                    # Method 2: description field (current format)
                    elif 'description' in file:
                        description = file['description']
                        name = description.split('\n')[0].split('/')[0]
                    # Method 3: title field (fallback)
                    elif 'title' in file:
                        name = file['title'].split('\n')[0]
                        description = name
                    else:
                        continue

                    logger.log('MediaFusion: Found name: %s' % name, log_utils.LOGDEBUG)

                    # Use direct stream URL from MediaFusion instead of creating magnet
                    if 'url' in file:
                        url = file['url']
                        logger.log('MediaFusion: Using direct stream URL: %s' % url, log_utils.LOGDEBUG)
                    else:
                        logger.log('MediaFusion: No URL found in stream data', log_utils.LOGWARNING)
                        continue

                    # Extract seeders - try multiple patterns
                    seeders = 0
                    if 'seeds' in file:
                        seeders = int(file.get('seeds', 0))
                    else:
                        # Look for seeders in description with emoji or text
                        seeder_patterns = [
                            r'👤\s*(\d+)',  # Emoji format
                            r'Seeders?:?\s*(\d+)',  # Text format
                            r'Seeds?:?\s*(\d+)'     # Alternative text format
                        ]
                        for pattern in seeder_patterns:
                            seeder_match = re.search(pattern, description, re.IGNORECASE)
                            if seeder_match:
                                seeders = int(seeder_match.group(1))
                                break

                    if self.min_seeders > seeders:
                        continue

                    # Extract quality from filename
                    quality = scraper_utils.get_tor_quality(name)

                    # Extract size information
                    size = 0
                    size_patterns = [
                        r'💾\s*([\d.]+)\s*(GB|MB)',  # Emoji format
                        r'📦\s*([\d.]+)\s*(GB|MB)',  # Box emoji format
                        r'([\d.]+)\s*(GB|MB)',  # Simple format with space
                        r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))',  # General format
                        r'Size:?\s*([\d.]+)\s*(GB|MB)'  # Text format
                    ]

                    for pattern in size_patterns:
                        size_match = re.search(pattern, description, re.IGNORECASE)
                        if size_match:
                            # Handle comma as decimal separator for European formats
                            size_value_str = size_match.group(1).replace(',', '.')
                            size_value = float(size_value_str)
                            size_unit = size_match.group(2).upper()
                            if size_unit.startswith('G'):
                                size = size_value * 1024  # Convert GB to MB
                            else:
                                size = size_value
                            break

                    # Create label with available information
                    label_parts = [name]
                    if size > 0:
                        label_parts.append(f"{size:.1f}MB")
                    if seeders > 0:
                        label_parts.append(f"{seeders} seeders")
                    label = " | ".join(label_parts)

                    source_item = {
                        'class': self,
                        'host': 'mediafusion',
                        'label': label,
                        'multi-part': False,
                        'seeders': seeders,
                        'name': name,
                        'quality': quality,
                        'size': size,
                        'language': 'en',
                        'url': url,
                        'direct': True,
                        'debridonly': False
                    }

                    sources.append(source_item)
                    logger.log('MediaFusion: Added source: %s' % source_item, log_utils.LOGDEBUG)

                except Exception as e:
                    logger.log('MediaFusion: Error processing source: %s' % str(e), log_utils.LOGERROR)
                    continue

        except Exception as e:
            logger.log('MediaFusion: Unexpected error in get_sources: %s' % str(e), log_utils.LOGERROR)

        logger.log('MediaFusion: Returning %d sources' % len(sources), log_utils.LOGDEBUG)
        return sources

    def search(self, video_type, title, year, season=''):
        """
        Search method implementation for MediaFusion scraper.
        MediaFusion requires IMDB IDs, so search functionality is limited.
        """
        logger.log('MediaFusion: Search not implemented - requires IMDB ID', log_utils.LOGDEBUG)
        return []
