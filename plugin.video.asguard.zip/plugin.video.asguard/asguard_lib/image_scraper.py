"""
    Asguard Addon
    Copyright (C) 2026 MrBlamo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Standard library imports
import datetime
import io, json, os, threading, random, socket, ssl, time, urllib.parse, urllib.request, xml.etree.ElementTree as ET, zipfile
import asyncio

# Third-party library imports
import cache, requests, six, urllib3
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

# Kodi-specific imports
import xbmcaddon

# Local module imports
import kodi, log_utils, utils
from asguard_lib import client, utils2
from asguard_lib.constants import VIDEO_TYPES
from asguard_lib.constants import *
from asguard_lib.db_utils import DB_Connection
logger = log_utils.Logger.get_logger(__name__)

# Since the image_cache module is now local, we can directly import it
from . import image_cache

CACHE_INSTALLED = 'image_cache' in globals()
index = random.randrange(len(RAND_UAS))
versions = {'win_ver': random.choice(WIN_VERS), 'feature': random.choice(FEATURES), 'br_ver': random.choice(BR_VERS[index])}
user_agent = RAND_UAS[index].format(**versions)
db_connection = DB_Connection()
PLACE_POSTER = os.path.join(kodi.get_path(), 'resources', 'place_poster.png')
DEFAULT_FANART = utils2.art('fanart.jpg')
OMDB_ENABLED = kodi.get_setting('omdb_enable') == 'true'
TVMAZE_ENABLED = kodi.get_setting('tvmaze_enable') == 'true'
FANARTTV_ENABLED = kodi.get_setting('fanart_enable') == 'true'
BG_ENABLED = kodi.get_setting('bg_enable') == 'true'
POSTER_ENABLED = kodi.get_setting('poster_enable') == 'true'
BANNER_ENABLED = kodi.get_setting('banner_enable') == 'true'
CLEARART_ENABLED = kodi.get_setting('clearart_enable') == 'true'
THUMB_ENABLED = kodi.get_setting('thumb_enable') == 'true'
OMDB_API = kodi.get_setting('omdb_api')
GIF_ENABLED = False

ZIP_CACHE = 24
OBJ_PERSON = 'person'
PROXY_TEMPLATE = 'http://127.0.0.1:{port}{action}'

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'


class SessionManager:
    _instance = None
    _session = None
    _executor = None
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
            cls._initialized = True
        return cls._instance
    
    def _initialize(self):
        """Initialize shared session and thread pool"""
        cls = SessionManager
        
        # Create shared session with connection pooling
        cls._session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=None,
            backoff_factor=0.3,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"]
        )
        
        # Mount adapter with connection pooling
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=15,
            pool_maxsize=15,
            pool_block=False
        )
        

        cls._session.mount('http://', adapter)
        cls._session.mount('https://', adapter)
        
        # Create shared thread pool with DAEMON threads
        cls._executor = ThreadPoolExecutor(
            max_workers=5, 
            thread_name_prefix='image_scraper',
            initializer=lambda: setattr(threading.current_thread(), "daemon", True)
        )

    @classmethod
    def get_session(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance._session
    
    @classmethod
    def get_executor(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance._executor
    
    @classmethod
    def close(cls):
        """Clean up resources"""
        if cls._instance:
            if cls._instance._executor:
                cls._instance._executor.shutdown(wait=False)
            if cls._instance._session:
                cls._instance._session.close()
            cls._instance = None
            cls._initialized = False

class Scraper(object):
    protocol = 'http://'
    def __init__(self):
        self.session = self._create_session()
        self.executor = self._create_executor()
        self.protocol = 'http://'


    
    def _create_session(self):
        """No longer needed - using shared session"""
        return SessionManager.get_session()
    
    def _create_executor(self):
        """No longer needed - using shared executor"""
        return SessionManager.get_executor()
    
    def _clean_art(self, art_dict):
        new_dict = {}
        for key in art_dict:
            if art_dict[key]:
                scheme, netloc, path, params, query, fragment = urllib.parse.urlparse(art_dict[key])
                new_dict[key] = urllib.parse.urlunparse((scheme, netloc, urllib.parse.quote(path), params, query, fragment))
        return new_dict
    

    
    def _get_url(self, url, params=None, data=None, headers=None, cache_limit=1, is_binary=False):
        """Get URL with improved performance using requests library"""
        if headers is None: 
            headers = {}
        
        # Prepare data if needed
        if data is not None:
            if isinstance(data, six.string_types):
                data = data
                logger.log('String image Data: %s' % (data), log_utils.LOGDEBUG)
            else:
                data = urllib.parse.urlencode(data, True)
                logger.log('Urlencode image Data: %s' % (data), log_utils.LOGDEBUG)
        
        # Build full URL if needed
        if not url.startswith('http'):
            url = '%s%s%s' % (self.protocol, self.BASE_URL, url)
            logger.log('Image Scrape URL: %s' % (url), log_utils.LOGDEBUG)
        
        # Add query parameters
        if params: 
            url += '?' + urllib.parse.urlencode(params)
            logger.log('Image Scrape URL with params: %s' % (url), log_utils.LOGDEBUG)
        # Check if this is a binary file request (ZIP, images, etc.)
        if url.lower().endswith('.zip') or any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif']):
            is_binary = True
        # Check cache first
        _created, cached_headers, html = db_connection.get_cached_url(url, data, cache_limit=cache_limit, is_binary=is_binary)
        if html:
            logger.log('Using Cached result for: %s' % (url))
            result = html
            res_headers = dict(cached_headers)
            logger.log('Result: %s' % (result), log_utils.LOGDEBUG)
        else:
            try:
                # Set default headers
                headers.setdefault('Accept-Encoding', 'gzip')
                headers.setdefault('Connection', 'keep-alive')
                headers.setdefault('User-Agent', user_agent)
                
                logger.log('+++Image Scraper Call: %s, header: %s, data: %s cache_limit: %s' % 
                          (url, headers, data, cache_limit), log_utils.LOGDEBUG)
                
                # Use requests session with timeout
                response = self.session.get(
                    url, 
                    data=data, 
                    headers=headers
                )
                response.raise_for_status()  # Raise exception for 4XX/5XX status codes
                
                # Get response content and headers
                result = response.content
                res_headers = dict(response.headers)
                
                # Cache the result
                db_connection.cache_url(url, result, data, res_header=res_headers)
                
            except requests.exceptions.Timeout:
                logger.log('Image Scraper Timeout: %s' % (url))
                return {}
            except requests.exceptions.HTTPError as e:
                if e.response.status_code != 404:
                    logger.log('HTTP Error (%s) during image scraper http get: %s' % (e, url), log_utils.LOGWARNING)
                return {}
            except Exception as e:
                logger.log('Error (%s) during image scraper http get: %s' % (str(e), url), log_utils.LOGWARNING)
                return {}
        
        try:
            # Process response based on content type
            content_type = res_headers.get('content-type', '').lower()
            if 'application/json' in content_type:
                return_data = utils.json_loads_as_str(result)
            else:
                # Try to parse as JSON, fallback to raw result
                try:
                    return_data = utils.json_loads_as_str(result)
                except ValueError:
                    return_data = result
        except ValueError:
            return_data = ''
            if result:
                logger.log('Invalid JSON API Response: %s - |%s|' % (url, return_data), log_utils.LOGERROR)
        
        return return_data
    
    def get_multiple_urls(self, url_list, params=None, headers=None, cache_limit=1):
        """
        Fetch multiple URLs concurrently using ThreadPoolExecutor
        
        Args:
            url_list: List of URLs to fetch
            params: Optional query parameters for all URLs
            headers: Optional headers for all URLs
            cache_limit: Cache duration in hours
            
        Returns:
            Dictionary mapping URLs to their responses
        """
        results = {}
        
        # Create a list of futures for each URL
        futures = {
            self.executor.submit(
                self._get_url, 
                url, 
                params, 
                None,  # No data for GET requests
                headers, 
                cache_limit
            ): url for url in url_list
        }
        
        # Process completed futures as they complete
        for future in as_completed(futures):
            url = futures[future]
            try:
                results[url] = future.result()
            except Exception as e:
                logger.log('Error fetching %s: %s' % (url, str(e)), log_utils.LOGWARNING)
                results[url] = {}
        
        return results
        
class FanartTVScraper(Scraper):
    API_KEY = kodi.get_setting('fanart_key')
    CLIENT_KEY = kodi.get_setting('fanart_person_key')
    BASE_URL = 'webservice.fanart.tv/v3'
    LANGS = {'en': 3, '00': 1, '': 2}

    def __init__(self):
        self.session = self._create_session()
        self.executor = self._create_executor()
    
        self.headers = {'api-key': self.API_KEY}
        if self.CLIENT_KEY:
            self.headers.update({'client-key': self.CLIENT_KEY})
        
    def get_movie_images(self, ids):
        logger.log('FanartTVScraper.get_movie_images: %s' % (ids), log_utils.LOGDEBUG)
        art_dict = {}
        video_id = ids.get('tmdb') or ids.get('imdb')
        any_art = any((BG_ENABLED, BANNER_ENABLED, POSTER_ENABLED, CLEARART_ENABLED))
        if FANARTTV_ENABLED and self.API_KEY and any_art and video_id:
            params = {'api_key': self.API_KEY}
            url = f'/movies/{video_id}'
            images = self._get_url(url, headers=self.headers, params=params)
            if BG_ENABLED:
                art_dict['fanart'] = self.__get_best_image(images.get('moviebackground', []))

            if THUMB_ENABLED:
                art_dict['thumb'] = self.__get_best_image(images.get('moviethumb', []))

            if BANNER_ENABLED:
                art_dict['banner'] = self.__get_best_image(images.get('moviebanner', []))

            if POSTER_ENABLED:
                art_dict['poster'] = self.__get_best_image(images.get('movieposter', []))

            if CLEARART_ENABLED:
                art_dict['clearlogo'] = self.__get_best_image(images.get('hdmovielogo', []))
                if not art_dict['clearlogo']: art_dict['clearlogo'] = self.__get_best_image(images.get('movielogo', []))
                art_dict['clearart'] = self.__get_best_image(images.get('hdmovieclearart', []))
        
        return self._clean_art(art_dict)
    
    def get_tvshow_images(self, ids):
        art_dict = {}
        video_id = ids.get('tvdb') or ids.get('imdb') or ids.get('trakt')
        any_art = any((BG_ENABLED, BANNER_ENABLED, POSTER_ENABLED, CLEARART_ENABLED, THUMB_ENABLED))
        if FANARTTV_ENABLED and self.API_KEY and 'tvdb' in ids and ids['tvdb'] and video_id and any_art:
            params = {'api_key': self.API_KEY}
            url = f'/tv/{video_id}'
            
            images = self._get_url(url, headers=self.headers, params=params)
            logger.log('FanartTVScraper.get_tvshow_images: %s' % (images), log_utils.LOGDEBUG)
            if BG_ENABLED:
                art_dict['fanart'] = self.__get_best_image(images.get('showbackground', []))

            if THUMB_ENABLED:
                art_dict['thumb'] = self.__get_best_image(images.get('tvthumb', []))

            if BANNER_ENABLED:
                art_dict['banner'] = self.__get_best_image(images.get('tvbanner', []))

            if POSTER_ENABLED:
                art_dict['poster'] = self.__get_best_image(images.get('tvposter', []))

            if CLEARART_ENABLED:
                art_dict['clearlogo'] = self.__get_best_image(images.get('hdtvlogo', []))
                if not art_dict['clearlogo']: art_dict['clearlogo'] = self.__get_best_image(images.get('clearlogo', []))
                art_dict['clearart'] = self.__get_best_image(images.get('hdclearart', []))
                if not art_dict['clearart']: art_dict['clearart'] = self.__get_best_image(images.get('clearart', []))
        
        return self._clean_art(art_dict)
    
    def get_season_images(self, ids):
        season_art = {}
        video_id = ids.get('tvdb') or ids.get('imdb') or ids.get('trakt') or ids.get('tmdb') or ids.get('code')
        any_art = any((BANNER_ENABLED, POSTER_ENABLED, THUMB_ENABLED))
        if FANARTTV_ENABLED and self.API_KEY and 'tvdb' in ids and ids['tvdb'] and video_id and any_art:
            params = {'api_key': self.API_KEY}
            url = f'/tv/{video_id}'
            images = self._get_url(url, headers=self.headers, params=params)
            seasons = set()
            for name in ['seasonposter', 'seasonthumb', 'seasonbanner']:
                seasons |= {str(i.get('season')) for i in images.get(name, []) if 'season' in i and i.get('season') is not None}

            for season in seasons:
                art_dict = {}
                if POSTER_ENABLED:
                    art_dict['poster'] = self.__get_best_image(images.get('seasonposter', []), season)

                if BANNER_ENABLED:
                    art_dict['banner'] = self.__get_best_image(images.get('seasonbanner', []), season)

                if THUMB_ENABLED:
                    art_dict['thumb'] = self.__get_best_image(images.get('seasonthumb', []), season)
                season_art[season] = self._clean_art(art_dict)
                
        return season_art
    
    def _extract_art(self, images, type_prefix):
        art_dict = {}
        if BG_ENABLED:
            art_dict['fanart'] = self.__get_best_image(images.get(f'{type_prefix}background', []))
        if THUMB_ENABLED:
            art_dict['thumb'] = self.__get_best_image(images.get(f'{type_prefix}thumb', []))
        if BANNER_ENABLED:
            art_dict['banner'] = self.__get_best_image(images.get(f'{type_prefix}banner', []))
        if POSTER_ENABLED:
            art_dict['poster'] = self.__get_best_image(images.get(f'{type_prefix}poster', []))
        if CLEARART_ENABLED:
            art_dict['clearlogo'] = self.__get_best_image(images.get(f'hdtvlogo', []), fallback_key=f'{type_prefix}logo')
            art_dict['clearart'] = self.__get_best_image(images.get(f'hdclearart', []), fallback_key=f'{type_prefix}clearart')
        return art_dict

    def _extract_season_art(self, images):
        season_art = {}
        seasons = set()
        for name in ['seasonposter', 'seasonthumb', 'seasonbanner']:
            seasons |= {str(i.get('season')) for i in images.get(name, []) if 'season' in i and i.get('season') is not None}
        
        for season in seasons:
            art_dict = {}
            if POSTER_ENABLED:
                art_dict['poster'] = self.__get_best_image(images.get('seasonposter', []), season)
            if BANNER_ENABLED:
                art_dict['banner'] = self.__get_best_image(images.get('seasonbanner', []), season)
            if THUMB_ENABLED:
                art_dict['thumb'] = self.__get_best_image(images.get('seasonthumb', []), season)
            season_art[season] = self._clean_art(art_dict)
        
        return season_art
    
    def __get_best_image(self, images, season=None, fallback_key=None):
        best = None
        images = [image for image in images if image.get('lang') in ('en', '00', '', 'ja')]
        if season is not None:
            images = [image for image in images if str(image.get('season')) == str(season)]
        if not images and fallback_key:
            images = [image for image in images if image.get('lang') in ('en', '00', '')]
        
        images.sort(key=lambda x: (self.LANGS.get(x.get('lang'), 0), int(x.get('likes', 0))), reverse=True)
        if images:
            best = images[0]['url']
        return best



    @staticmethod
    def _get_image_size(art):
        if art in ('hdtvlogo', 'hdclearart', 'hdmovielogo', 'hdmovieclearart'):
            return 800
        elif art in ('clearlogo', 'clearart', 'movielogo', 'movieart', 'musiclogo'):
            return 400
        elif art in ('tvbanner', 'seasonbanner', 'moviebanner'):
            return 1000
        elif art in ('showbackground', 'moviebackground'):
            return 1920
        elif art in ('tvposter', 'seasonposter', 'movieposter'):
            return 1426
        elif art in ('tvthumb', 'seasonthumb'):
            return 500
        elif art == 'characterart':
            return 512
        elif art == 'moviethumb':
            return 1000
        return 0


class TMDBScraper(Scraper):
    API_KEY = kodi.get_setting('tmdb_key')
    protocol = 'https://'
    BASE_URL = 'api.themoviedb.org/3'
    headers = {'Content-Type': 'application/json'}
    size = 'original'
    image_base = None

    def _get_url(self, url, params=None, data=None, headers=None, cache_limit=1):
        # Call parent class's _get_url with appropriate parameters
        result = super()._get_url(url, params=params, data=data, headers=headers, cache_limit=cache_limit)
    
        logger.log(f'TMDB Art URL: {url} | Result: {result}', log_utils.LOGDEBUG)
        # If result is already a dict (from successful JSON parsing), return it
        if isinstance(result, dict):
            return result

    # Ensure result is properly decoded if it's bytes
        if isinstance(result, (bytes, bytearray)):
            try:
                # gzip magic header
                if result[:2] == b'\x1f\x8b':
                    result = utils.json_loads_as_str(utils2.ungz(result))
                else:
                    result = utils.json_loads_as_str(result)
            except Exception as e:
                logger.log('FANARTTV decode error: %s' % (e), log_utils.LOGDEBUG)
                result = {}
        
        # Parse JSON if result is a string
        if isinstance(result, str):
            try:
                return utils.json_loads_as_str(result)
            except ValueError as e:
                logger.log(f'Failed to parse JSON: {e}', log_utils.LOGERROR)
                return {}
        
        return result or {}

    def __get_image_base(self):
        if self.API_KEY:
            if self.image_base is None:
                url = f'{self.protocol}{self.BASE_URL}/configuration'
                params = {'api_key': self.API_KEY}
                js_data = self._get_url(url, params, headers=self.headers, cache_limit=24)
                try: 
                    self.image_base = f"{js_data['images']['base_url']}{self.size}/"
                except KeyError: 
                    self.image_base = None
        else:
            self.image_base = None
        return self.image_base
            
    def get_movie_images(self, ids, need=None):
        if need is None: need = ['fanart', 'poster']
        art_dict = {}
        any_art = any((BG_ENABLED, POSTER_ENABLED))
        if 'tmdb' in ids and ids['tmdb'] and any_art and self.__get_image_base():
            images = image_cache.get_movie_images(ids['tmdb']) if CACHE_INSTALLED else {}
            if not images:
                url = f'{self.protocol}{self.BASE_URL}/movie/{ids["tmdb"]}/images'
                params = {'api_key': self.API_KEY, 'include_image_language': 'en,null'}
                images = self._get_url(url, params, headers=self.headers)
                
            if BG_ENABLED and 'fanart' in need:
                art_dict['fanart'] = self.__get_best_image(images.get('backdrops', []))
            
            if POSTER_ENABLED and 'poster' in need:
                art_dict['poster'] = self.__get_best_image(images.get('posters', []))

        return self._clean_art(art_dict)
    
    def get_tmdbshow_images(self, ids, need=None):
        if need is None: need = ['fanart', 'poster']
        art_dict = {}
        any_art = any((BG_ENABLED, POSTER_ENABLED))
        if 'tmdb' in ids and ids['tmdb'] and any_art and self.__get_image_base():
            images = image_cache.get_tv_images(ids['tmdb']) if CACHE_INSTALLED else {}
            if not images:
                url = f'{self.protocol}{self.BASE_URL}/tv/{ids["tmdb"]}/images'
                params = {'api_key': self.API_KEY, 'include_image_language': 'en,null'}
                images = self._get_url(url, params, headers=self.headers)
                
            if BG_ENABLED and 'fanart' in need:
                art_dict['fanart'] = self.__get_best_image(images.get('backdrops', []))
            
            if POSTER_ENABLED and 'poster' in need:
                art_dict['poster'] = self.__get_best_image(images.get('posters', []))

        return self._clean_art(art_dict)

    def get_tmdb_season_images(self, ids, season, need=None):
        if need is None: need = ['fanart', 'poster']
        art_dict = {}
        any_art = any((BG_ENABLED, POSTER_ENABLED))
        if 'tmdb' in ids and ids['tmdb'] and any_art and self.__get_image_base():
            images = image_cache.get_season_images(ids['tmdb'], season) if CACHE_INSTALLED else {}
            if not images:
                url = f'{self.protocol}{self.BASE_URL}/tv/{ids["tmdb"]}/season/{season}/images'
                params = {'api_key': self.API_KEY, 'include_image_language': 'en,null'}
                images = self._get_url(url, params, headers=self.headers)
                logger.log(f"TMDB Season Images - {images}", log_utils.LOGDEBUG)

                # Cache the response for future use
                if images and CACHE_INSTALLED:
                    from asguard_lib.image_cache import local_lib
                    cache_db = local_lib.db_utils.DBCache()
                    unique_key = f"{season}"
                    # Use the public execute method instead of private __execute
                    cache_db.execute('REPLACE INTO api_cache (tmdb_id, object_type, data) values (?, ?, ?)',
                                  (ids['tmdb'], f"S_{unique_key}", json.dumps(images)))
                    cache_db.close()

            
            # Process posters (season images)
            if images and 'posters' in images and images['posters']:
                # Sort by vote_average and vote_count to get the best image
                best_still = sorted(images['posters'], 
                                 key=lambda x: (x.get('vote_average', 0), x.get('vote_count', 0)), 
                                 reverse=True)[0]
                
                # Build the full image URL
                image_path = best_still.get('file_path', '')
                if image_path:
                    full_url = f"{self.image_base}{image_path}"
                    
                    # Use the same image for poster, thumb and fanart for episodes
                    if POSTER_ENABLED and 'poster' in need:
                        art_dict['poster'] = full_url
                    if BG_ENABLED and 'fanart' in need:
                        art_dict['fanart'] = full_url
                    
                    # Also set thumb if needed
                    art_dict['thumb'] = full_url
                    
                    logger.log(f"TMDB Season Images - Selected image: {full_url}", log_utils.LOGDEBUG)

        return self._clean_art(art_dict)

    def get_tmdbepisode_images(self, ids, season, episode, need=None):
        if need is None: need = ['fanart', 'poster']
        art_dict = {}
        any_art = any((BG_ENABLED, POSTER_ENABLED))
        if 'tmdb' in ids and ids['tmdb'] and any_art and self.__get_image_base():
            images = image_cache.get_episode_images(ids['tmdb'], season, episode) if CACHE_INSTALLED else {}
            if not images:
                url = f'{self.protocol}{self.BASE_URL}/tv/{ids["tmdb"]}/season/{season}/episode/{episode}/images'
                params = {'api_key': self.API_KEY, 'include_image_language': 'en,null'}
                images = self._get_url(url, params, headers=self.headers)
                

                # Cache the response for future use
                if images and CACHE_INSTALLED:
                    from asguard_lib.image_cache import local_lib
                    cache_db = local_lib.db_utils.DBCache()
                    unique_key = f"{season}_{episode}"
                    # Use the public execute method instead of private __execute
                    cache_db.execute('REPLACE INTO api_cache (tmdb_id, object_type, data) values (?, ?, ?)',
                                  (ids['tmdb'], f"E_{unique_key}", json.dumps(images)))
                    cache_db.close()

            
            # Process stills (episode images)
            if images and 'stills' in images and images['stills']:
                # Sort by vote_average and vote_count to get the best image
                best_still = sorted(images['stills'], 
                                 key=lambda x: (x.get('vote_average', 0), x.get('vote_count', 0)), 
                                 reverse=True)[0]
                
                # Build the full image URL
                image_path = best_still.get('file_path', '')
                if image_path:
                    full_url = f"{self.image_base}{image_path}"
                    
                    # Use the same image for poster, thumb and fanart for episodes
                    if POSTER_ENABLED and 'poster' in need:
                        art_dict['poster'] = full_url
                    if BG_ENABLED and 'fanart' in need:
                        art_dict['fanart'] = full_url
                    
                    # Also set thumb if needed
                    art_dict['thumb'] = full_url
                    
                    logger.log(f"TMDB Episode Images - Selected image: {full_url}", log_utils.LOGDEBUG)

        return self._clean_art(art_dict)

    def get_person_images(self, ids):
        person_art = {}
        if 'tmdb' in ids and ids['tmdb'] and self.__get_image_base():
            images = image_cache.get_person_images(ids['tmdb']) if CACHE_INSTALLED else {}
            if not images:
                url = f'{self.protocol}{self.BASE_URL}/person/{ids["tmdb"]}/images'
                params = {'api_key': self.API_KEY, 'include_image_language': 'en,null'}
                images = self._get_url(url, params, headers=self.headers, cache_limit=30)
                
            person_art['thumb'] = self.__get_best_image(images.get('profiles', []))
        return self._clean_art(person_art)
            
    def __get_best_image(self, images):
        best = None
        if images:
            images.sort(key=lambda x: x['width'], reverse=True)
            best = images[0]['file_path']
        
        if best:
            best = f"{self.image_base}{best}"
            
        return best
    

class TVDBScraper(Scraper):
    API_KEY = kodi.get_setting('tvdb_key')  # Ensure this setting name matches the one used in settings.xml for the new API key
    V4_APIKEY = {'apikey': 'b64a2c35-ba29-4353-b46c-1e306874afb6'}
    protocol = 'https://'
    BASE_URL = 'api.thetvdb.com'
    BASE_URL_V4 = 'api4.thetvdb.com/v4'
    ART_URL_V4 = 'artworks.thetvdb.com'
    ZIP_URL = 'thetvdb.com'
    EP_CACHE = {}
    CAST_CACHE = {}
    headers = {'Content-Type': 'application/json'}
    image_base = 'http://thetvdb.com/banners/'
    token = None
    
    def __get_token(self):
        if self.V4_APIKEY:
            if self.token is None:
                url = self.protocol + self.BASE_URL_V4 + '/login'
                data = {'apikey': self.V4_APIKEY}
                res = client.request(
                    url,
                    headers=self.headers,
                    post=data,
                    jpost=True
                )
                js_data = json.loads(res)
                self.token = js_data.get('token')
                self.headers.update({'Authorization': 'Bearer %s' % (self.token)})
        else:
            self.token = None
        
        return self.token
        
    def get_tvshow_images(self, ids, need=None):
        art_dict = {}
        if need is None: need = ['fanart', 'poster', 'banner']
        any_art = any((BG_ENABLED, POSTER_ENABLED, BANNER_ENABLED))
        if 'tvdb' in ids and ids['tvdb'] and self.API_KEY and any_art:
            images = self.__get_images(self.__get_xml(ids['tvdb'], 'banners.xml'))
            if BG_ENABLED and 'fanart' in need:
                art_dict['fanart'] = self.__get_best_image(images.get('fanart', []))
            
            if POSTER_ENABLED and 'poster' in need:
                art_dict['poster'] = self.__get_best_image(images.get('poster', []))
    
            if BANNER_ENABLED and 'banner' in need:
                art_dict['banner'] = self.__get_best_image(images.get('series', []))
            
        return self._clean_art(art_dict)
    
    def get_tvshow_images_v2(self, ids, need=None):
        art_dict = {}
        if need is None: need = ['fanart', 'poster', 'banner']
        any_art = any((BG_ENABLED, POSTER_ENABLED, BANNER_ENABLED))
        logger.log('get_tvshow_images_v2: %s' % (ids), log_utils.LOGDEBUG)
        if 'tvdb' in ids and ids['tvdb'] and any_art and self.__get_token():
            url = '/series/%s/images/query' % (ids['tvdb'])
            logger.log('url: %s' % (url), log_utils.LOGDEBUG)
            if BG_ENABLED and 'fanart' in need:
                params = {'keyType': 'fanart'}
                images = self._get_url(url, params, headers=self.headers)
                logger.log('images: %s' % (images), log_utils.LOGDEBUG)
                art_dict['fanart'] = self.__get_best_image(images.get('data', []))
            
            if POSTER_ENABLED and 'poster' in need:
                params = {'keyType': 'poster'}
                images = self._get_url(url, params, headers=self.headers)
                art_dict['poster'] = self.__get_best_image(images.get('data', []))
            
            if BANNER_ENABLED and 'banner' in need:
                params = {'keyType': 'series'}
                images = self._get_url(url, params, headers=self.headers)
                art_dict['banner'] = self.__get_best_image(images.get('data', []))
            
        return self._clean_art(art_dict)
    
    def get_season_images(self, ids, need=None):
        season_art = {}
        if need is None: need = ['poster', 'banner']
        any_art = any((BANNER_ENABLED, POSTER_ENABLED))
        logger.log('get_tvdb_season_images: %s' % (ids), log_utils.LOGDEBUG)
        if 'tvdb' in ids and ids['tvdb'] and self.API_KEY and any_art:
            xml = self.__get_xml(ids['tvdb'], 'banners.xml')
            logger.log('TVDB banners.xml: %s' % (xml), log_utils.LOGDEBUG)
            images = self.__get_images(xml)
            logger.log('TVDB images: %s' % (images), log_utils.LOGDEBUG)
            seasons = set([image['subKey'] for image in images.get('season', [])])
            seasons |= set([image['subKey'] for image in images.get('seasonwide', [])])
            
            for season in seasons:
                art_dict = {}
                if POSTER_ENABLED:
                    art_dict['poster'] = self.__get_best_image(images.get('season', []), season)
                
                if BANNER_ENABLED:
                    art_dict['banner'] = self.__get_best_image(images.get('seasonwide', []), season)
                    
                season_art[season] = self._clean_art(art_dict)
                
        return season_art
        
    def get_season_images_v2(self, ids, need=None):
        season_art = {}
        if need is None: need = ['poster', 'banner']
        any_art = any((BANNER_ENABLED, POSTER_ENABLED))
        if 'tvdb' in ids and ids['tvdb'] and any_art and self.__get_token():
            url = '/series/%s/images/query' % (ids['tvdb'])
            images = {}
            seasons = set()
            if POSTER_ENABLED and 'poster' in need:
                params = {'keyType': 'season'}
                images['season'] = self._get_url(url, params, headers=self.headers).get('data', [])
                seasons |= set([i['subKey'] for i in images.get('season', [])])
            
            if BANNER_ENABLED and 'banner' in need:
                params = {'keyType': 'seasonwide'}
                images['seasonwide'] = self._get_url(url, params, headers=self.headers).get('data', [])
                seasons |= set([i['subKey'] for i in images.get('seasonwide', [])])
                
            for season in seasons:
                art_dict = {}
                art_dict['poster'] = self.__get_best_image(images.get('season', []), season)
                art_dict['banner'] = self.__get_best_image(images.get('seasonwide', []), season)
                season_art[season] = self._clean_art(art_dict)
                
        return season_art
    
    def get_episode_images(self, ids, season, episode):
        ep_art = {}
        if 'tvdb' in ids and ids['tvdb'] and self.API_KEY and THUMB_ENABLED:
            tvdb = ids['tvdb']
            season = int(season)
            episode = int(episode)
            try: TVDBScraper.EP_CACHE[tvdb][season]
            except KeyError: self.__build_ep_cache(tvdb, season)

            try: ep_art['thumb'] = self.image_base + TVDBScraper.EP_CACHE[tvdb][season][episode]
            except KeyError: pass
                
        return ep_art
        
    def get_cast(self, tvdb):
        cast = []
        if tvdb in TVDBScraper.CAST_CACHE:
            cast = TVDBScraper.CAST_CACHE[tvdb]
        elif self.API_KEY and self.__zip_is_cached(tvdb):
            xml = self.__get_xml(tvdb, 'actors.xml')
            for actor in ET.fromstring(xml).findall('.//Actor'):
                name = actor.findtext('Name')
                role = actor.findtext('Role')
                thumbnail = actor.findtext('Image')
                if name and role:
                    if thumbnail:
                        thumbnail = self.image_base + thumbnail
                    cast.append({'name': name, 'role': role, 'thumb': thumbnail})
            TVDBScraper.CAST_CACHE[tvdb] = cast

        return cast
    
    def __zip_is_cached(self, tvdb):
        url = 'http://thetvdb.com/api/%s/series/%s/all/en.zip' % (self.API_KEY, tvdb)
        created, _res_header, _html = db_connection.get_cached_url(url)
        return time.time() - created < ZIP_CACHE * 60 * 60
        
    def __build_ep_cache(self, tvdb, season=None):
        show_dict = TVDBScraper.EP_CACHE.setdefault(tvdb, {})
        xml = self.__get_xml(tvdb, 'en.xml')
        logger.log('TVDB xml: %s' % (xml), log_utils.LOGDEBUG)
        
        # can't use predicates yet because ET 1.3 is Python 2.7
        for item in ET.fromstring(xml).findall('.//Episode'):
            try: item_season = int(item.findtext('SeasonNumber', -1))
            except: continue
            try: item_episode = int(item.findtext('EpisodeNumber', -1))
            except: continue
            thumb = item.findtext('filename')
            if (season is None or int(season) == item_season) and thumb:
                season_dict = show_dict.setdefault(item_season, {})
                season_dict[item_episode] = thumb
    
    
    def __get_xml(self, tvdb, file_name):
        xml = '<xml/>'
        if self.API_KEY:
            url = 'http://thetvdb.com/api/%s/series/%s/all/en.zip' % (self.API_KEY, tvdb)
            zip_data = self._get_url(url, cache_limit=ZIP_CACHE, is_binary=True)
            if zip_data:
                try:
                    with zipfile.ZipFile(io.BytesIO(zip_data), 'r') as zip_file:
                        xml = zip_file.read(file_name).decode('utf-8')
                except zipfile.BadZipFile:
                    logger.log('TVDB Zip Error: Bad Zip File', log_utils.LOGWARNING)
                except UnicodeDecodeError:
                    logger.log('TVDB Zip Error: Unicode Decode Error', log_utils.LOGWARNING)
        return xml
        
    def __get_images(self, xml):
        images = {}
        for image_ele in ET.fromstring(xml).findall('.//Banner'):
            language = image_ele.findtext('Language')
            if language == 'en' or not language:
                base_type = image_ele.findtext('BannerType')
                subKey = image_ele.findtext('Season')
                file_name = image_ele.findtext('BannerPath')
                # Default resolution value can be BannerType2 (often resolution) or 0
                resolution = image_ele.findtext('BannerType2')

                if base_type == 'season':
                    # TVDB sometimes places resolution (e.g., '680x1000') in BannerType2 for season posters
                    # Use BannerPath to differentiate posters vs seasonwide banners
                    if file_name and 'seasonswide' in file_name:
                        image_type = 'seasonwide'
                    else:
                        image_type = 'season'
                    if resolution is None:
                        resolution = 0
                else:
                    image_type = base_type

                if image_type:
                    try:
                        average = float(image_ele.findtext('Rating'))
                    except:
                        average = 0.0
                    try:
                        count = int(image_ele.findtext('RatingCount'))
                    except:
                        count = 0
                    image = {
                        'subKey': subKey,
                        'resolution': resolution,
                        'ratingsInfo': {'average': average, 'count': count},
                        'fileName': file_name
                    }
                    images.setdefault(image_type, []).append(image)

        return images
        
    def __get_best_image(self, images, season=None):
        best = None
        if season is not None:
            images = [image for image in images if image['subKey'] == season]
                
        if images:
            images.sort(key=lambda x: (x['resolution'], x['ratingsInfo']['average'], x['ratingsInfo']['count']), reverse=True)
            best = images[0]['fileName']
            
        if best:
            best = self.image_base + best
            
        return best

class TVDBAPI(Scraper):
    def __init__(self):
        self.session = self._create_session()
        self.executor = self._create_executor()
        self.apiKey = {'apikey': 'b64a2c35-ba29-4353-b46c-1e306874afb6'}
        self.headers = {'User-Agent': 'Asguard'}
        self.baseUrl = 'https://api4.thetvdb.com/v4/'
        self.art = {}
        self.request_response = None
        self.threads = []

    def get_token(self):
        res = client.request(
            self.baseUrl + 'login',
            headers=self.headers,
            post=self.apiKey,
            jpost=True
        )
        data = json.loads(res)
        return data['data'].get('token')

    def get_request(self, url):
        token = cache.get(self.get_token, 24)
        self.headers.update({'Authorization': 'Bearer {0}'.format(token)})
        url = self.baseUrl + url

        response = client.request(url, headers=self.headers)
        if response:
            response = json.loads(response).get('data')
            self.request_response = response
            return response
        else:
            return None

    def get_imdb_id(self, tvdb_id):
        imdb_id = None
        url = 'series/{}/extended'.format(tvdb_id)
        data = self.get_request(url)
        if data:
            imdb_id = [x.get('id') for x in data['remoteIds'] if x.get('type') == 2]
        return imdb_id[0] if imdb_id else None

    def get_seasons(self, tvdb_id):
        url = 'seasons/{}/extended'.format(tvdb_id)
        data = self.get_request(url)
        return data

class TVMazeScraper(Scraper):
    BASE_URL = 'api.tvmaze.com'


    def get_episode_images(self, ids, season, episode):
        art_dict = {}
        if not TVMAZE_ENABLED:
            return art_dict
        
        if 'tvdb' in ids and ids['tvdb']:
            key = 'thetvdb'
            video_id = ids['tvdb']
        elif 'imdb' in ids and ids['imdb']:
            key = 'imdb'
            video_id = ids['imdb']
        elif 'tvrage' in ids and ids['tvrage']:
            key = 'tvrage'
            video_id = ids['tvrage']
        elif 'tmdb' in ids and ids['tmdb']:
            key = 'tmdb'
            video_id = ids['tmdb']
        else:
            return art_dict
        
        url = '/lookup/shows'
        params = {key: video_id}
        js_data = self._get_url(url, params, cache_limit=24 * 7)
        logger.log('js_data: %s' % (js_data), log_utils.LOGDEBUG)
        if 'id' in js_data and js_data['id']:
            art_dict['poster'] = self.__get_image(js_data)
            url = '/shows/%s/episodes' % (js_data['id'])
            logger.log('url: %s' % (url), log_utils.LOGDEBUG)
            for ep_item in self._get_url(url, cache_limit=24):
                logger.log('ep_item: %s' % (ep_item), log_utils.LOGDEBUG)
                if ep_item['season'] == int(season) and ep_item['number'] == int(episode):
                    art_dict['thumb'] = self.__get_image(ep_item)
                    break
                
        return self._clean_art(art_dict)
    
    def __get_image(self, item):
        image = item.get('image', {})
        image = image.get('original') if image else None
        return image

class IMDBScraper(Scraper):
    BASE_URL = 'https://www.imdb.com'
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

    def _fetch(self, url):
        headers = {'User-Agent': self.UA, 'Accept-Language': 'en-US,en;q=0.9'}
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.read()

    def _extract_poster(self, html_bytes):
        try:
            soup = BeautifulSoup(html_bytes, 'html.parser')
            meta = soup.find('meta', property='og:image')
            if meta and meta.get('content'):
                return meta['content']
            for script in soup.find_all('script', type='application/ld+json'):
                try:
                    data = json.loads(script.string or '')
                except Exception:
                    continue
                image = data.get('image')
                if isinstance(image, str):
                    return image
                if isinstance(image, dict):
                    url = image.get('url')
                    if url:
                        return url
                if isinstance(image, list) and image:
                    if isinstance(image[0], str):
                        return image[0]
                    if isinstance(image[0], dict) and image[0].get('url'):
                        return image[0]['url']
        except Exception as e:
            logger.log(f'IMDb poster parse error: {e}', log_utils.LOGDEBUG)
        return None

    def _extract_img_from_container(self, container):
        img = container.find('img')
        if not img:
            return None
        for attr in ('srcset', 'data-srcset'):
            srcset = img.get(attr)
            if srcset:
                try:
                    parts = [p.strip().split(' ')[0] for p in srcset.split(',') if p.strip()]
                    if parts:
                        return parts[-1]
                except Exception:
                    pass
        for attr in ('src', 'data-src', 'loadlate'):
            if img.get(attr):
                return img[attr]
        return None

    def get_movie_images(self, imdb_id):
        art = {}
        if isinstance(imdb_id, dict):
            imdb_id = imdb_id.get('imdb')
        if not imdb_id:
            return art
        try:
            html = self._fetch(f'{self.BASE_URL}/title/{imdb_id}/')
            poster = self._extract_poster(html)
            if poster:
                art['poster'] = poster
        except Exception as e:
            logger.log(f'IMDb movie fetch error: {e}', log_utils.LOGWARNING)
        return self._clean_art(art)

    def get_tvshow_images(self, ids):
        art = {}
        imdb_id = ids.get('imdb') if isinstance(ids, dict) else ids
        if not imdb_id:
            return art
        try:
            html = self._fetch(f'{self.BASE_URL}/title/{imdb_id}/')
            poster = self._extract_poster(html)
            if poster:
                art['poster'] = poster
        except Exception as e:
            logger.log(f'IMDb tvshow fetch error: {e}', log_utils.LOGWARNING)
        return self._clean_art(art)

    def get_episode_images(self, ids, season, episode):
        art = {}
        imdb_id = ids.get('imdb') if isinstance(ids, dict) else ids
        if not imdb_id:
            return art
        try:
            html = self._fetch(f'{self.BASE_URL}/title/{imdb_id}/episodes?season={season}')
            soup = BeautifulSoup(html, 'html.parser')
            candidate = None
            for container in soup.find_all(['div', 'li', 'section']):
                epnum = container.get('data-episode-number')
                if epnum and str(epnum).strip() == str(int(episode)):
                    candidate = container
                    break
                badge = container.find(attrs={'data-testid': 'episode-item-episode-number'})
                if badge and badge.get_text(strip=True).isdigit() and int(badge.get_text(strip=True)) == int(episode):
                    candidate = container
                    break
                meta_num = container.find('meta', itemprop='episodeNumber')
                if meta_num and meta_num.get('content') and int(meta_num['content']) == int(episode):
                    candidate = container
                    break
            if candidate:
                img_url = self._extract_img_from_container(candidate)
                if img_url:
                    art['thumb'] = img_url
        except Exception as e:
            logger.log(f'IMDb episode fetch/parse error: {e}', log_utils.LOGWARNING)
        return self._clean_art(art)

class OMDBScraper(Scraper):
    BASE_URL = 'www.omdbapi.com'
    
    def get_images(self, ids):
        art_dict = {}
        omdb_api_key = OMDB_API
        # Only proceed if OMDb is enabled, poster fetching is enabled, and an API key is configured
        if not (OMDB_ENABLED and POSTER_ENABLED and omdb_api_key):
            return self._clean_art(art_dict)
        imdb_id = ids.get('imdb') if isinstance(ids, dict) else None
        if not imdb_id:
            return self._clean_art(art_dict)
        url = ''
        params = {'i': imdb_id, 'plot': 'short', 'r': 'json', 'apikey': omdb_api_key}
        images = self._get_url(url, params)
        # If the HTTP/cache layer returned bytes (often gzipped), decode to JSON
        if isinstance(images, (bytes, bytearray)):
            try:
                # gzip magic header
                if images[:2] == b'\x1f\x8b':
                    images = utils.json_loads_as_str(utils2.ungz(images))
                else:
                    images = utils.json_loads_as_str(images)
            except Exception as e:
                logger.log('OMDB decode error: %s' % (e), log_utils.LOGDEBUG)
                images = {}
        if isinstance(images, dict) and images.get('Poster') and images['Poster'].startswith('http'):
            art_dict['poster'] = images['Poster']
        return self._clean_art(art_dict)

fanart_scraper = FanartTVScraper()
omdb_scraper = OMDBScraper()
tvmaze_scraper = TVMazeScraper()
imdb_scraper = IMDBScraper()
tvdbapi_scraper = TVDBAPI()
tvdb_scraper = TVDBScraper()
tmdb_scraper = TMDBScraper()

    
def get_person_images(video_ids, person, cached=True):
    if cached:
        ids = person['person']['ids']
        port = kodi.get_setting('proxy_port')
        video_ids = urllib.parse.quote(json.dumps(video_ids))
        params = {'image_type': 'thumb', 'video_type': OBJ_PERSON, 'trakt_id': ids['trakt'], 'video_ids': video_ids, 'name': person['person']['name'],
                  'person_ids': json.dumps(ids)}
        image_url = PROXY_TEMPLATE.format(port=port, action='') + '?' + urllib.parse.urlencode(params)
        return {'thumb': image_url}
    else:
        return scrape_person_images(video_ids, person, cached)

def scrape_person_images(video_ids, person, cached=True):
    person_art = {}
    ids = person['person']['ids']
    if cached:
        cached_art = db_connection.get_cached_images(OBJ_PERSON, ids['trakt'])
        if cached_art:
            person_art.update(cached_art)
    else:
        cached_art = {}
    
    if not cached_art:
        logger.log('Getting person images for |%s| in media |%s|' % (person, video_ids), log_utils.LOGDEBUG)
        tried = False
        if not person_art.get('thumb') and 'tvdb' in video_ids and video_ids['tvdb']:
            norm_name = utils2.normalize_title(person['person']['name'])
            for member in tvdb_scraper.get_cast(video_ids['tvdb']):
                tried = True
                if norm_name == utils2.normalize_title(member['name']):
                    logger.log('Found %s as |%s| in %s' % (person['person']['name'], norm_name, video_ids))
                    person_art['thumb'] = member['thumb']
                    break
        
        if not person_art.get('thumb') and 'tmdb' in ids and ids['tmdb']:
            tried = True
            person_art.update(tmdb_scraper.get_person_images(ids))
        
        # cache the person's art if we tried to get the art
        if tried: db_connection.cache_images(OBJ_PERSON, ids['trakt'], person_art)
            
    return person_art

def clear_cache(video_type, video_ids, season='', episode=''):
    trakt_id = video_ids['trakt']
    port = kodi.get_setting('proxy_port')
    params = {'video_type': video_type, 'trakt_id': trakt_id, 'video_ids': video_ids}
        
    if video_type == VIDEO_TYPES.SEASON or video_type == VIDEO_TYPES.EPISODE:
        params['season'] = season
    
    if video_type == VIDEO_TYPES.EPISODE:
        params['episode'] = episode
        
    url = PROXY_TEMPLATE.format(port=port, action='/clear') + '?' + urllib.parse.urlencode(params)
    try: 
        res = urllib.request.urlopen(url, timeout=30).read()
    except Exception as e: 
        logger.log(f"Failed to clear cache: {str(e)}", log_utils.LOGWARNING)
        res = ''
    return res == 'OK'


def get_images(video_type, video_ids, season='', episode='', cached=True):
    if cached:
        port = kodi.get_setting('proxy_port')
        trakt_id = video_ids['trakt']
        video_ids = json.dumps(video_ids)
        art_dict = {}
        
        # Only create proxy URLs for enabled image types
        enabled_types = ['fanart', 'thumb', 'poster']  # Always enabled
        if BANNER_ENABLED:
            enabled_types.append('banner')
        if CLEARART_ENABLED:
            enabled_types.append('clearart')
            enabled_types.append('clearlogo')
        
        for image_type in enabled_types:
            params = {'image_type': image_type, 'video_type': video_type, 'trakt_id': trakt_id, 'video_ids': video_ids}
            # logger.log('image_scraper params: %s' % params)
            if video_type == VIDEO_TYPES.SEASON or video_type == VIDEO_TYPES.EPISODE:
                params['season'] = season

            if video_type == VIDEO_TYPES.EPISODE:
                params['episode'] = episode
            image_url = PROXY_TEMPLATE.format(port=port, action='') + '?' + urllib.parse.urlencode(params)
            # logger.log('image_scraper image_url: %s' % image_url)
            art_dict[image_type] = image_url
        return art_dict
    else:
        return scrape_images(video_type, video_ids, season, episode, cached)



def scrape_images(video_type, video_ids, season='', episode='', cached=True):
    """
    Fetch images from multiple scrapers in parallel for improved performance.

    This version executes multiple scraper calls concurrently instead of sequentially,
    significantly reducing wait time when images are not cached.

    Args:
        video_type: Type of video (MOVIE, TVSHOW, SEASON, EPISODE)
        video_ids: Dictionary containing various IDs (trakt, tmdb, imdb, tvdb, etc.)
        season: Season number (for TV shows)
        episode: Episode number (for episodes)
        cached: Whether to check cache first

    Returns:
        Dictionary containing image URLs for different art types
    """
    art_dict = {
        'banner': None,
        'fanart': DEFAULT_FANART,
        'thumb': None,
        'poster': PLACE_POSTER,
        'clearart': None,
        'clearlogo': None
    }

    trakt_id = video_ids.get('trakt')
    object_type = VIDEO_TYPES.MOVIE if video_type == VIDEO_TYPES.MOVIE else VIDEO_TYPES.TVSHOW

    # Check cache first
    if cached:
        cached_art = db_connection.get_cached_images(object_type, trakt_id, season, episode)
        if cached_art:
            art_dict.update(cached_art)
            return art_dict
    else:
        cached_art = {}

    # If not in cache, fetch from scrapers in parallel
    if not cached_art:
        global fanart_scraper, omdb_scraper, tvmaze_scraper, tvdb_scraper, tmdb_scraper, imdb_scraper

        if video_type == VIDEO_TYPES.MOVIE:
            if  POSTER_ENABLED:
                art_dict.update(fanart_scraper.get_movie_images(video_ids))
            # if GIF_ENABLED and POSTER_ENABLED:
            #     art_dict.update(gif_scraper.get_movie_images(video_ids))
             
            need = []
            if art_dict['fanart'] == DEFAULT_FANART: need.append('fanart')
            if art_dict['poster'] == PLACE_POSTER: need.append('poster')
            if need:
                art_dict.update(tmdb_scraper.get_movie_images(video_ids, need))
                
            if art_dict['poster'] == PLACE_POSTER:
                art_dict.update(omdb_scraper.get_images(video_ids))
            # Cache and return
            db_connection.cache_images(object_type, trakt_id, art_dict, season, episode)

        elif video_type == VIDEO_TYPES.TVSHOW:
            art_dict.update(fanart_scraper.get_tvshow_images(video_ids))
             
            need = []
            if art_dict['fanart'] == DEFAULT_FANART: need.append('fanart')
            if art_dict['poster'] == PLACE_POSTER: need.append('poster')
            if not art_dict['banner']: need.append('banner')
            if need:
                art_dict.update(tvdb_scraper.get_tvshow_images(video_ids, need))
                
            
            if art_dict['poster'] == PLACE_POSTER:
                art_dict.update(imdb_scraper.get_tvshow_images(video_ids))
            # Cache and return
            db_connection.cache_images(object_type, trakt_id, art_dict, season, episode)

        elif video_type == VIDEO_TYPES.SEASON:
            art_dict = scrape_images(VIDEO_TYPES.TVSHOW, video_ids, cached=cached)
            season_art = fanart_scraper.get_season_images(video_ids)
            logger.log('season_art: %s' % season_art)
            tvdb_season_art = tvdb_scraper.get_season_images(video_ids)
            logger.log('tvdb_season_art: %s' % tvdb_season_art)
            
            for key in tvdb_season_art:
                tvdb_poster = tvdb_season_art[key].get('poster')
                tvdb_banner = tvdb_season_art[key].get('banner')

                if tvdb_poster and not season_art.get(key, {}).get('poster'):
                    season_art.setdefault(key, {}).setdefault('poster', tvdb_poster)

                if tvdb_banner and not season_art.get(key, {}).get('banner'):
                    season_art.setdefault(key, {}).setdefault('banner', tvdb_banner)
            
            for key in season_art:
                temp_dict = art_dict.copy()
                temp_dict.update(season_art[key])
                db_connection.cache_images(object_type, trakt_id, temp_dict, key)
            
            art_dict.update(season_art.get(str(season), {}))

            # Cache and return
            db_connection.cache_images(object_type, trakt_id, art_dict, season, episode)

        elif video_type == VIDEO_TYPES.EPISODE:
            art_dict = scrape_images(VIDEO_TYPES.TVSHOW, video_ids, cached=cached)
            art_dict.update(tvdb_scraper.get_episode_images(video_ids, season, episode))

            need = []
            if art_dict['fanart'] == DEFAULT_FANART: need.append('fanart')
            if art_dict['poster'] == PLACE_POSTER: need.append('poster')
            if not art_dict['banner']: need.append('banner')
            if need:
                art_dict.update(tmdb_scraper.get_tmdbepisode_images(video_ids, season, episode))

            if not art_dict['thumb'] or art_dict['poster'] == PLACE_POSTER:
                tvmaze_art = tvmaze_scraper.get_episode_images(video_ids, season, episode)
                art_dict['thumb'] = tvmaze_art.get('thumb')
                if art_dict['poster'] == PLACE_POSTER and 'poster' in tvmaze_art:
                    art_dict['poster'] = tvmaze_art['poster']
                    

            # Cache and return
            db_connection.cache_images(object_type, trakt_id, art_dict, season, episode)

            # Apply fallbacks
    _apply_fallbacks(art_dict, video_type)

            # Cache the final results
    db_connection.cache_images(object_type, trakt_id, art_dict, season, episode)

    return art_dict


def _execute_scraper_tasks(tasks, max_workers=4, timeout=15):

    """
    Execute multiple scraper tasks in parallel using the shared SessionManager executor.

    Args:
        tasks: List of tuples (name, function, args)
        timeout: Maximum time to wait for each task

    Returns:
        Dictionary mapping task names to their results
    """
    results = {}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        futures = {
            executor.submit(func, *args): name 
            for name, func, args in tasks
        }

        # Collect results as they complete
        for future in as_completed(futures, timeout=timeout):
            task_name = futures[future]
            try:
                result = future.result(timeout=timeout)
                results[task_name] = result
            except Exception as e:
                logger.log(f'Error in {task_name} scraper: {str(e)}', log_utils.LOGWARNING)
                results[task_name] = {}


    return results



def _apply_fallbacks(art_dict, video_type):
    """
    Apply fallback logic for missing images.

    Args:
        art_dict: Dictionary containing image URLs
        video_type: Type of video (MOVIE, TVSHOW, SEASON, EPISODE)
    """
    # Thumb fallback
    if not art_dict.get('thumb'):
        logger.log(f'Doing {video_type} thumb fallback |{art_dict}|', log_utils.LOGDEBUG)
        if video_type == VIDEO_TYPES.MOVIE:
            if art_dict.get('poster') != PLACE_POSTER:
                art_dict['thumb'] = art_dict['poster']
            elif art_dict.get('fanart') != DEFAULT_FANART:
                art_dict['thumb'] = art_dict['fanart']
            else:
                art_dict['thumb'] = art_dict['poster']
        else:
            if art_dict.get('fanart') != DEFAULT_FANART:
                art_dict['thumb'] = art_dict['fanart']
            elif art_dict.get('poster') != PLACE_POSTER:
                art_dict['thumb'] = art_dict['poster']
            else:
                art_dict['thumb'] = art_dict['fanart']

    # Fanart fallback
    elif art_dict.get('fanart') == DEFAULT_FANART:
        logger.log(f'Doing {video_type} fanart fallback |{art_dict}|', log_utils.LOGDEBUG)
        art_dict['fanart'] = art_dict['thumb']

