# Trakt Playback Tracking Fix Analysis

## Problem Description

The Asguard addon experiences intermittent issues with Trakt playback tracking where it stops tracking playback progress. This issue can occur randomly, sometimes after months of normal operation. Re-authenticating both the Trakt Kodi addon and Asguard temporarily resolves the issue, suggesting a token management problem.

## Root Cause Analysis

After analyzing the `__call_trakt` method in `trakt_api.py`, several potential issues have been identified:

### 1. Token Refresh Logic Issues (Lines 791-808)

The current token refresh logic has several potential failure points:

```python
elif status in (401, 405):
    # token is fine, profile is private
    if r.headers.get('X-Private-User') == 'true':
        raise TraktAuthError('Object is No Longer Available (%s)' % (status))
    # auth failure retry or a token request
    elif auth_retry or url.endswith('/oauth/token'):
        self.token = None
        kodi.set_setting('trakt_oauth_token', '')
        kodi.set_setting('trakt_refresh_token', '')
        raise TraktAuthError('Trakt Call Authentication Failed (%s)' % (status))
    # first try token fail, try to refresh token
    else:
        result = self.refresh_token(kodi.get_setting('trakt_refresh_token'))
        self.token = result['access_token']
        kodi.set_setting('trakt_oauth_token', result['access_token'])
        kodi.set_setting('trakt_refresh_token', result['refresh_token'])
        auth_retry = True
        continue
```

**Issues:**
- If `refresh_token` fails, the code doesn't handle the exception properly
- The code assumes `result` will always contain 'access_token' and 'refresh_token', which may not be true if the refresh fails
- There's no notification to the user when re-authentication is needed
- The `auth_retry` flag is set to True but only allows one retry attempt

### 2. Missing Error Handling for Token Refresh

When the token refresh fails, the code doesn't properly handle the situation:

```python
result = self.refresh_token(kodi.get_setting('trakt_refresh_token'))
self.token = result['access_token']
kodi.set_setting('trakt_oauth_token', result['access_token'])
kodi.set_setting('trakt_refresh_token', result['refresh_token'])
```

If `refresh_token` returns None or raises an exception, the subsequent lines will fail, potentially leaving the system in an inconsistent state.

### 3. No Token Validation Before Use

The code doesn't validate that the token is still valid before using it. This can lead to failed API calls when the token has expired but the refresh logic hasn't been triggered.

### 4. Silent Failures in Playback Tracking

When playback tracking fails due to authentication issues, there's no indication to the user that tracking has stopped. This makes it difficult to diagnose the problem.

## Proposed Solutions

### Solution 1: Enhanced Token Refresh with Error Handling

Modify the token refresh logic to properly handle failures and notify the user:

```python
elif status in (401, 405):
    # token is fine, profile is private
    if r.headers.get('X-Private-User') == 'true':
        raise TraktAuthError('Object is No Longer Available (%s)' % (status))
    # auth failure retry or a token request
    elif auth_retry or url.endswith('/oauth/token'):
        self.token = None
        kodi.set_setting('trakt_oauth_token', '')
        kodi.set_setting('trakt_refresh_token', '')
        kodi.notify(msg='Trakt authentication failed. Please re-authenticate.', duration=5000)
        raise TraktAuthError('Trakt Call Authentication Failed (%s)' % (status))
    # first try token fail, try to refresh token
    else:
        try:
            refresh_token = kodi.get_setting('trakt_refresh_token')
            if not refresh_token:
                logger.log('No refresh token available, re-authentication required', log_utils.LOGERROR)
                kodi.notify(msg='Trakt authentication expired. Please re-authenticate.', duration=5000)
                raise TraktAuthError('No refresh token available')

            result = self.refresh_token(refresh_token)
            if not result or 'access_token' not in result or 'refresh_token' not in result:
                logger.log('Token refresh failed, re-authentication required', log_utils.LOGERROR)
                kodi.notify(msg='Trakt token refresh failed. Please re-authenticate.', duration=5000)
                raise TraktAuthError('Token refresh failed')

            self.token = result['access_token']
            kodi.set_setting('trakt_oauth_token', result['access_token'])
            kodi.set_setting('trakt_refresh_token', result['refresh_token'])
            auth_retry = True
            continue
        except Exception as e:
            logger.log('Token refresh exception: %s' % str(e), log_utils.LOGERROR)
            kodi.notify(msg='Trakt authentication error. Please re-authenticate.', duration=5000)
            raise TraktAuthError('Token refresh exception: %s' % str(e))
```

### Solution 2: Implement Token Validation

Add a method to validate the token before use:

```python
def validate_token(self):
    """
    Validate that the current token is still valid by making a simple API call
    Returns True if valid, False otherwise
    """
    try:
        url = '/users/me'
        headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
        headers.update({'Authorization': 'Bearer %s' % (self.token)})
        r = session.request('GET', '%s%s' % (self.protocol, BASE_URL) + url, headers=headers, timeout=self.timeout)
        return r.status_code == 200
    except Exception as e:
        logger.log('Token validation failed: %s' % str(e), log_utils.LOGERROR)
        return False
```

Then modify `__call_trakt` to validate the token before making API calls:

```python
if auth:
    # Validate token before use
    if not self.validate_token():
        logger.log('Token validation failed, attempting refresh', log_utils.LOGWARNING)
        try:
            refresh_token = kodi.get_setting('trakt_refresh_token')
            if not refresh_token:
                raise TraktAuthError('No refresh token available')

            result = self.refresh_token(refresh_token)
            if not result or 'access_token' not in result:
                raise TraktAuthError('Token refresh failed')

            self.token = result['access_token']
            kodi.set_setting('trakt_oauth_token', result['access_token'])
            kodi.set_setting('trakt_refresh_token', result['refresh_token'])
        except Exception as e:
            logger.log('Token refresh failed: %s' % str(e), log_utils.LOGERROR)
            kodi.notify(msg='Trakt authentication failed. Please re-authenticate.', duration=5000)
            raise TraktAuthError('Authentication failed')

    headers.update({'Authorization': 'Bearer %s' % (self.token)})
```

### Solution 3: Add Token Health Check

Implement a periodic token health check in the service:

```python
def check_token_health(self):
    """
    Check token health and refresh if needed
    """
    try:
        expires_str = kodi.get_setting('trakt.expires')
        if expires_str:
            expires = float(expires_str)
            # Refresh if token expires in less than 24 hours
            if (expires - time.time()) < 86400:
                logger.log('Token expiring soon, attempting refresh', log_utils.LOGINFO)
                refresh_token = kodi.get_setting('trakt_refresh_token')
                if refresh_token:
                    result = self.refresh_token(refresh_token)
                    if result and 'access_token' in result:
                        self.token = result['access_token']
                        kodi.set_setting('trakt_oauth_token', result['access_token'])
                        kodi.set_setting('trakt_refresh_token', result['refresh_token'])
                        logger.log('Token refreshed successfully', log_utils.LOGINFO)
                    else:
                        logger.log('Token refresh failed', log_utils.LOGERROR)
                        kodi.notify(msg='Trakt token refresh failed. Please re-authenticate.', duration=5000)
    except Exception as e:
        logger.log('Token health check failed: %s' % str(e), log_utils.LOGERROR)
```

Add this check to the service main loop:

```python
# In service.py main loop
if service.tracked and service.isPlayingVideo():
    service._lastPos = service.getTime()

# Check token health every hour
if int(time.time()) % 3600 == 0:
    trakt_api = Trakt_API(TOKEN, use_https, list_size, trakt_timeout, trakt_offline)
    trakt_api.check_token_health()
```

### Solution 4: Implement Fallback to script.trakt Token

If the Asguard addon's token fails, attempt to use the script.trakt addon's token as a fallback:

```python
def get_script_trakt_token(self):
    """
    Attempt to get the token from script.trakt addon
    Returns the token if available, None otherwise
    """
    try:
        import json
        trakt_addon = xbmcaddon.Addon('script.trakt')
        authorization = trakt_addon.getSetting('authorization')
        if authorization:
            auth_data = json.loads(authorization)
            return auth_data.get('access_token')
    except Exception as e:
        logger.log('Failed to get script.trakt token: %s' % str(e), log_utils.LOGERROR)
    return None

def __call_trakt(self, url: str, method: str = None, data: Any = None, params: dict = None, auth: bool = True, cache_limit: float = .25, cached: bool = True) -> Union[str, list, dict, Any]:
    # ... existing code ...

    if auth:
        # Try primary token first
        if not self.token:
            self.token = kodi.get_setting('trakt_oauth_token')

        # If primary token fails, try fallback
        if not self.token:
            self.token = self.get_script_trakt_token()
            if self.token:
                logger.log('Using script.trakt token as fallback', log_utils.LOGINFO)

        if not self.token:
            raise TraktAuthError('No authentication token available')

        headers.update({'Authorization': 'Bearer %s' % (self.token)})
```

### Solution 5: Add Playback Tracking Status Monitoring

Add monitoring of playback tracking status and notify the user if tracking stops:

```python
# In service.py
def monitor_trakt_tracking(self):
    """
    Monitor Trakt tracking status and notify if tracking stops
    """
    if self.tracked and self.isPlayingVideo():
        # Check if tracking is still active by checking last successful scrobble
        last_scrobble = kodi.get_setting('trakt_last_scrobble')
        if last_scrobble:
            last_scrobble_time = float(last_scrobble)
            # If no scrobble in the last 5 minutes, tracking may have stopped
            if time.time() - last_scrobble_time > 300:
                logger.log('Trakt tracking may have stopped', log_utils.LOGWARNING)
                kodi.notify(msg='Trakt tracking may have stopped. Check your authentication.', duration=5000)
```

Add this check to the service main loop:

```python
# In service.py main loop
if service.tracked and service.isPlayingVideo():
    service._lastPos = service.getTime()
    service.monitor_trakt_tracking()
```

## Implementation Recommendations

1. **Priority 1**: Implement Solution 1 (Enhanced Token Refresh with Error Handling)
   - This addresses the most immediate issue of token refresh failures
   - Provides user notification when re-authentication is needed
   - Prevents silent failures

2. **Priority 2**: Implement Solution 2 (Token Validation)
   - Prevents failed API calls by validating tokens before use
   - Reduces the likelihood of tracking interruptions

3. **Priority 3**: Implement Solution 3 (Token Health Check)
   - Proactively refreshes tokens before they expire
   - Reduces the likelihood of tracking interruptions

4. **Priority 4**: Implement Solution 4 (Fallback to script.trakt Token)
   - Provides a fallback mechanism if the primary token fails
   - Improves reliability of the system

5. **Priority 5**: Implement Solution 5 (Playback Tracking Status Monitoring)
   - Provides visibility into tracking status
   - Helps diagnose issues when they occur

## Testing Recommendations

1. Test token refresh scenarios:
   - Token expiring naturally
   - Token being revoked
   - Refresh token being invalid

2. Test playback tracking scenarios:
   - Normal playback
   - Playback with token refresh
   - Playback with token failure

3. Test error handling:
   - Network failures
   - API failures
   - Authentication failures

4. Test user notifications:
   - Verify notifications are shown when re-authentication is needed
   - Verify notifications are clear and actionable

## Conclusion

The intermittent Trakt playback tracking issues in the Asguard addon are primarily caused by inadequate token refresh and error handling in the `__call_trakt` method. By implementing the solutions outlined above, particularly Solution 1 (Enhanced Token Refresh with Error Handling), the reliability of Trakt playback tracking can be significantly improved.

The key improvements are:
1. Better error handling for token refresh failures
2. User notification when re-authentication is needed
3. Token validation before use
4. Proactive token refresh
5. Fallback mechanisms
6. Monitoring of tracking status

These changes will make the system more robust and provide better visibility into issues when they occur, making it easier to diagnose and fix problems.
