# TMDB API Comparison: POV vs Asguard

## Overview

This document compares the TMDB (The Movie Database) API implementations between the POV Kodi addon and the Asguard (SALTS Fork) addon. Both add-ons use the TMDB API to fetch movie and TV show metadata, but they implement it differently with distinct features and approaches.

## Table of Contents

1. [Architecture & Design](#architecture--design)
2. [Caching Strategy](#caching-strategy)
3. [API Features](#api-features)
4. [Error Handling](#error-handling)
5. [Performance Optimizations](#performance-optimizations)
6. [Code Organization](#code-organization)
7. [Key Differences Summary](#key-differences-summary)

---

## Architecture & Design

### POV Implementation

**File Location:** `resources/lib/indexers/tmdb_api.py`

**Key Characteristics:**
- Uses `requests.Session()` with connection pooling
- Implements retry strategy using `requests.adapters.Retry`
- Utilizes a dual-cache system (main cache + meta cache)
- Modular function-based architecture with clear separation of concerns
- Supports both TMDB API v3 and v4 endpoints
- Uses ThreadPoolExecutor for concurrent operations

**Session Configuration:**
```python
session = requests.Session()
retry = requests.adapters.Retry(total=None, status=1, status_forcelist=(429, 502, 503, 504))
session.mount('https://api.themoviedb.org', requests.adapters.HTTPAdapter(pool_maxsize=100, max_retries=retry))
```

**Timeout Settings:**
- Base timeout: 3.05 seconds
- List operations: timeout squared (9.3 seconds)

### Asguard Implementation

**File Location:** `asguard_lib/tmdb_api.py`

**Key Characteristics:**
- Uses `requests.Session()` with more robust retry configuration
- Implements a multi-layer caching system (memory + database)
- Includes rate limiting to prevent API throttling
- Uses Trakt ID cross-referencing
- More defensive error handling with try-except blocks
- Includes cleanup functions for resource management

**Session Configuration:**
```python
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"],
    backoff_factor=0.3
)
adapter = HTTPAdapter(pool_connections=5, pool_maxsize=15, max_retries=retry_strategy)
```

**Timeout Settings:**
- Base timeout: 10 seconds
- Rate limit delay: 150ms between requests

---

## Caching Strategy

### POV Implementation

**Cache Types:**
1. **Main Cache** (`cache_object`): Used for most API responses
2. **Meta Cache** (`cache_function`): Used for specific metadata operations

**Cache Durations:**
- 4 hours: EXPIRES_4_HOURS (search queries)
- 2 days: EXPIRES_2_DAYS (popular/trending content)
- 1 week: EXPIRES_1_WEEK (keywords, companies, images, videos)
- 1 month: EXPIRES_1_MONTH (title/year searches, external IDs)
- 1 year: EXPIRES_1_WEEK * 52 (translations)

**Cache Key Format:**
```python
string = 'tmdb_function_name_%s' % parameters
```

**Cache Clearing:**
- Implements `clear_tmdbl_cache()` function for TMDB list cache management
- Direct database operations for cache invalidation

### Asguard Implementation

**Cache Types:**
1. **In-Memory Cache** (`SimpleCache`): Fast access to frequently used data
2. **Database Cache** (`DB_Connection`): Persistent cache for long-term storage

**Cache Configuration:**
```python
CACHE_DURATION = 28800  # 8 Hours
RATE_LIMIT_DELAY = 0.15  # 150ms between requests
```

**Cache Key Format:**
```python
def _cache_key(url, params):
    import hashlib
    key_string = f"tmdb_api_{url}_{str(sorted(params.items()) if params else '')}"
    return hashlib.md5(key_string.encode()).hexdigest()
```

**Cache Flow:**
1. Check in-memory cache first
2. Check database cache if memory miss
3. Make API request if both caches miss
4. Store result in both caches (write-through)

**Cache Management:**
- Implements `clear_cache()` function
- Provides `get_cache_stats()` for monitoring
- Automatic cleanup via `__del__()` destructor

---

## API Features

### POV Implementation

**Movie Functions:**
- `tmdb_movies_popular(page_no)` - Popular movies
- `tmdb_movies_blockbusters(page_no)` - High revenue movies
- `tmdb_movies_premieres(page_no)` - Recent theatrical releases
- `tmdb_movies_latest_releases(page_no)` - Recent digital releases
- `tmdb_movies_upcoming(page_no)` - Future releases
- `tmdb_movies_genres(genre_id, page_no)` - Filter by genre
- `tmdb_movies_year(year, page_no)` - Filter by year
- `tmdb_movies_networks(network_id, page_no)` - Filter by network/company
- `tmdb_movies_similar(tmdb_id, page_no)` - Similar movies
- `tmdb_movies_recommendations(tmdb_id, page_no)` - Recommended movies
- `tmdb_movies_search(query, page_no)` - Search movies
- `tmdb_movies_search_collections(query, page_no)` - Search collections
- `tmdb_movies_collection(collection_id)` - Get collection details
- `tmdb_movies_title_year(title, year)` - Search by title and year
- `movie_details(tmdb_id, language)` - Get full movie details
- `movie_external_id(external_source, external_id)` - Find by external ID
- `movie_title_year(title, year)` - Search with caching
- `movie_keywords(tmdb_id)` - Get movie keywords

**TV Show Functions:**
- `tmdb_tv_popular(page_no)` - Popular TV shows
- `tmdb_tv_premieres(page_no)` - Recent TV premieres
- `tmdb_tv_upcoming(page_no)` - Upcoming TV shows
- `tmdb_tv_genres(genre_id, page_no)` - Filter by genre
- `tmdb_tv_year(year, page_no)` - Filter by year
- `tmdb_tv_networks(network_id, page_no)` - Filter by network
- `tmdb_tv_similar(tmdb_id, page_no)` - Similar TV shows
- `tmdb_tv_recommendations(tmdb_id, page_no)` - Recommended TV shows
- `tmdb_tv_search(query, page_no)` - Search TV shows
- `tvshow_details(tmdb_id, language)` - Get full TV show details
- `tvshow_external_id(external_source, external_id)` - Find by external ID
- `tvshow_title_year(title, year)` - Search with caching
- `season_episodes_details(tmdb_id, season_no, language)` - Get season details

**Anime Functions:**
- `tmdb_moviesanime_popular(page_no)` - Popular anime movies
- `tmdb_moviesanime_latest_releases(page_no)` - Recent anime releases
- `tmdb_moviesanime_genres(genre_id, page_no)` - Filter anime movies by genre
- `tmdb_moviesanime_year(year, page_no)` - Filter anime movies by year
- `tmdb_tvanime_popular(page_no)` - Popular anime TV shows
- `tmdb_tvanime_premieres(page_no)` - Recent anime premieres
- `tmdb_tvanime_genres(genre_id, page_no)` - Filter anime TV by genre
- `tmdb_tvanime_year(year, page_no)` - Filter anime TV by year

**People Functions:**
- `tmdb_popular_people(page_no)` - Popular people
- `tmdb_people_full_info(actor_id, language)` - Get full actor info
- `tmdb_people_info(query)` - Search people

**List Management (TMDB API v4):**
- `tmdb_watchlist(mediatype, page, letter)` - Get user watchlist
- `tmdb_favorites(mediatype, page, letter)` - Get user favorites
- `tmdb_recommendations(mediatype, page, letter)` - Get recommendations
- `add_to_watchlist_favorites(item, list_type)` - Add item to list
- `user_lists()` - Get user lists
- `list_details(list_id)` - Get list details
- `list_add_items(list_id, items)` - Add items to list
- `list_remove_items(list_id, items)` - Remove items from list
- `list_update(list_id, data)` - Update list
- `list_status(list_id, mediatype, media_id)` - Check item status
- `list_create(list_name)` - Create new list
- `list_clear(list_id)` - Clear list
- `list_delete(list_id)` - Delete list
- `tmdb_clean_watchlist(silent)` - Clean watchlist based on watched status
- `import_trakt_list(params)` - Import Trakt list to TMDB
- `import_mdbl_list(params)` - Import MDbList to TMDB

**Other Functions:**
- `tmdb_keyword_id(query)` - Get keyword ID
- `tmdb_company_id(query)` - Get company ID
- `tmdb_media_images(mediatype, tmdb_id)` - Get media images
- `tmdb_media_videos(mediatype, tmdb_id)` - Get media videos
- `english_translation(mediatype, tmdb_id)` - Get English translations
- `episode_groups(tmdb_id)` - Get episode groups
- `episode_group_details(group_id)` - Get episode group details
- `get_dates(days, reverse)` - Helper for date calculations
- `tmdb_image_params(language)` - Helper for image language parameters

### Asguard Implementation

**Core Functions:**
- `authenticate_tmdb()` - Authenticate with TMDB API
- `search_tmdb(query, page, overview)` - Search for movies
- `search_tmdb_tv(query, page, include_adult)` - Search for TV shows
- `search_tmdb_tv_multi_page(query, max_pages, include_adult)` - Multi-page TV search
- `get_tv_details(tmdb_id, overview, trakt_id)` - Get TV show details
- `get_tv_seasons(tmdb_id)` - Get TV show seasons
- `get_season_episodes(tmdb_id, season_number, overview, trakt_id)` - Get season episodes
- `get_all_results(query)` - Get all search results for a query
- `fetch_tmdb_metadata(imdb_id, trakt_id)` - Fetch metadata by IMDB ID
- `get_tv_episode_groups(tmdb_id)` - Get episode groups
- `get_episode_group_details(group_id)` - Get episode group details
- `get_tv_details_batch(tmdb_ids, overview)` - Batch get TV details

**Utility Functions:**
- `clear_cache()` - Clear TMDB API cache
- `get_cache_stats()` - Get cache statistics
- `cleanup()` - Cleanup resources
- `__del__()` - Destructor for cleanup

**Helper Functions:**
- `_get_session()` - Get or create requests session
- `_cache_key(url, params)` - Generate cache key
- `_get_cached_response(cache_key)` - Get cached response
- `_cache_response(cache_key, data)` - Cache response data
- `_rate_limited_request(url, params, timeout)` - Make rate-limited request

---

## Error Handling

### POV Implementation

**Error Handling Strategy:**
- Uses try-except blocks for API requests
- Logs errors using custom logger
- Returns None or empty results on error
- Limited error recovery mechanisms

**Example:**
```python
def get_tmdb(url):
    try:
        response = session.get(url, timeout=timeout)
        result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
        if not response.ok: response.raise_for_status()
        return result
    except requests.RequestException as e:
        logger('tmdb error', str(e))
```

**Error Handling in Functions:**
```python
def movie_details(tmdb_id, language, tmdb_api=None):
    try:
        url = '%s/movie/%s?api_key=%s&language=%s&append_to_response=%s' % (base_url, tmdb_id, get_tmdb_api(tmdb_api), language, movies_append)
        if language not in 'en,en-US': url += '&include_image_language=%s' % tmdb_image_params(language)
        return get_tmdb(url)
    except: return None
```

### Asguard Implementation

**Error Handling Strategy:**
- More comprehensive error handling
- Catches specific exceptions (Timeout, RequestException, ValueError)
- Logs detailed error messages with context
- Returns empty dictionaries on error
- Implements retry logic for transient failures

**Example:**
```python
def _rate_limited_request(url, params=None, timeout=REQUEST_TIMEOUT):
    # ... caching code ...
    try:
        response = session.get(url, params=params, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        # ... caching code ...
        return data
    except requests.exceptions.Timeout:
        logger.log(f'Request timeout for URL: {url}', log_utils.LOGERROR)
        return {}
    except requests.exceptions.RequestException as e:
        logger.log(f'Request failed: {e}', log_utils.LOGERROR)
        return {}
    except ValueError as e:
        logger.log(f'Error parsing JSON: {e}', log_utils.LOGERROR)
        return {}
```

**Cleanup Error Handling:**
```python
def cleanup():
    global _session
    if _session is not None:
        try:
            _session.close()
            logger.log('TMDB Session closed properly', log_utils.LOGDEBUG)
        except Exception as e:
            logger.log(f'Error closing TMDB Session: {e}', log_utils.LOGERROR)
        finally:
            _session = None
```

---

## Performance Optimizations

### POV Implementation

**Optimizations:**
1. **Connection Pooling:**
   - Uses `requests.Session()` with pool_maxsize=100
   - Reuses connections for multiple requests

2. **Retry Strategy:**
   - Automatic retries for status codes 429, 502, 503, 504
   - Configurable retry count and backoff

3. **Concurrent Operations:**
   - Uses ThreadPoolExecutor for parallel requests
   - Implements TaskPool for thread management

4. **Caching:**
   - Multi-level caching with different expiration times
   - Cache invalidation based on content type

5. **Pagination:**
   - Efficient pagination with page limit settings
   - Paginated list operations for large datasets

**Example of Concurrent Operations:**
```python
with ThreadPoolExecutor() as tpe:
    for result in tpe.map(list_request, args):
        if isinstance(result, dict): items.extend(result['results'])
```

### Asguard Implementation

**Optimizations:**
1. **Connection Pooling:**
   - Uses `requests.Session()` with pool_connections=5, pool_maxsize=15
   - Reuses connections for multiple requests

2. **Retry Strategy:**
   - Comprehensive retry strategy with backoff factor
   - Supports both old and new urllib3 parameter names
   - Retries for status codes 429, 500, 502, 503, 504

3. **Rate Limiting:**
   - Implements rate limiting with 150ms delay between requests
   - Uses threading.Lock for thread-safe rate limiting
   - Tracks last request time to enforce delays

4. **Multi-Layer Caching:**
   - In-memory cache for fast access
   - Database cache for persistent storage
   - Write-through caching strategy

5. **Batch Operations:**
   - Implements `get_tv_details_batch()` for efficient batch requests
   - Checks cache before making API calls for each item

**Example of Rate Limiting:**
```python
with _rate_limit_lock:
    current_time = time.time()
    time_since_last = current_time - _last_request_time
    if time_since_last < RATE_LIMIT_DELAY:
        sleep_time = RATE_LIMIT_DELAY - time_since_last
        logger.log(f'Rate limiting: sleeping {sleep_time:.3f}s', log_utils.LOGDEBUG)
        time.sleep(sleep_time)
    _last_request_time = time.time()
```

---

## Code Organization

### POV Implementation

**Structure:**
- Imports and configuration at the top
- Constants defined clearly
- Helper functions first
- Movie functions grouped together
- TV show functions grouped together
- Anime functions grouped together
- People functions grouped together
- List management functions grouped together
- Utility functions at the end

**Imports:**
```python
import requests
from threading import Thread
from concurrent.futures import ThreadPoolExecutor
from caches.main_cache import cache_object
from caches.meta_cache import cache_function
from modules import kodi_utils
from modules.settings import tmdb_api_key, get_language, show_unaired_watchlist, ignore_articles, lists_sort_order, paginate, page_limit
from modules.utils import paginate_list, sort_for_article, jsondate_to_datetime, get_datetime, chunks, TaskPool
```

**Constants:**
```python
EXPIRES_4_HOURS, EXPIRES_2_DAYS, EXPIRES_1_WEEK, EXPIRES_1_MONTH = 4, 48, 168, 672
READ_TOKEN = get_setting('tmdb_read_token')
movies_append = 'external_ids,videos,credits,release_dates,alternative_titles,translations,images'
tvshows_append = 'external_ids,videos,credits,content_ratings,alternative_titles,translations,images'
eps_map = {1: 'Original air date', 2: 'Absolute', 3: 'DVD', 4: 'Digital', 5: 'Story arc', 6: 'Production', 7: 'TV'}
tmdb_image_base, tmdb_list_heading = 'https://image.tmdb.org/t/p/%s%s', 'TMDB Lists'
list_url = 'https://api.themoviedb.org/4'
base_url = 'https://api.themoviedb.org/3'
timeout = 3.05
```

### Asguard Implementation

**Structure:**
- Imports and configuration at the top
- Constants defined clearly
- Session management functions
- Cache management functions
- Rate limiting and request functions
- Core API functions
- Utility and cleanup functions

**Imports:**
```python
import requests, json, time, threading
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import log_utils
import xbmcgui
import simplecache
import xbmcaddon
import kodi
from functools import wraps
from asguard_lib import control
from asguard_lib.db_utils import DB_Connection
```

**Constants:**
```python
TMDB_API_KEY = kodi.get_setting('tmdb_key')
BEARER_TOKEN = kodi.get_setting('tmdb_bearer_token')
TMDB_API_URL = 'https://api.themoviedb.org/3'
TMDB_SEARCH_URL = 'https://api.themoviedb.org/3/search/movie'
TMDB_SEARCH_TV_URL = 'https://api.themoviedb.org/3/search/tv'
TMDB_TV_DETAILS_URL = 'https://api.themoviedb.org/3/tv/{}'
TMDB_SEASON_DETAILS_URL = 'https://api.themoviedb.org/3/tv/{}/season/{}'
TMDB_EPISODE_GROUPS_URL = 'https://api.themoviedb.org/3/tv/{}/episode_groups'
TMDB_EPISODE_GROUPS_DETAILS_URL = 'https://api.themoviedb.org/3/tv/episode_group/{}'
CACHE_DURATION = 28800  # 8 Hours
RATE_LIMIT_DELAY = 0.15  # 150ms between requests
REQUEST_TIMEOUT = 10  # 10 second timeout
```

---

## Key Differences Summary

### Architecture

| Aspect | POV | Asguard |
|--------|-----|---------|
| Session Management | Single session with large pool | Single session with moderate pool |
| API Versions | Supports v3 and v4 | Primarily v3 |
| Timeout | 3.05s (base), 9.3s (lists) | 10s (all) |
| Retry Strategy | Basic retry with status codes | Comprehensive retry with backoff |

### Caching

| Aspect | POV | Asguard |
|--------|-----|---------|
| Cache Types | Main cache + Meta cache | Memory cache + Database cache |
| Cache Duration | Variable (4h to 1 month) | Fixed (8 hours) |
| Cache Key | String-based | MD5 hash-based |
| Cache Clearing | Manual function | Manual + automatic cleanup |

### Features

| Feature | POV | Asguard |
|---------|-----|---------|
| Movie Search | ✓ | ✓ |
| TV Search | ✓ | ✓ |
| Anime Support | ✓ | ✗ |
| List Management | ✓ (TMDB v4) | ✗ |
| People Search | ✓ | Limited |
| Episode Groups | ✓ | ✓ |
| Rate Limiting | ✗ | ✓ |
| Batch Operations | Limited | ✓ |
| Trakt Integration | ✗ | ✓ |

### Error Handling

| Aspect | POV | Asguard |
|--------|-----|---------|
| Exception Handling | Basic | Comprehensive |
| Error Logging | Basic | Detailed |
| Error Recovery | Limited | Better |
| Cleanup | Manual | Automatic |

### Performance

| Aspect | POV | Asguard |
|--------|-----|---------|
| Connection Pooling | Large (100) | Moderate (15) |
| Concurrent Operations | ThreadPoolExecutor | Rate limiting |
| Caching Strategy | Multi-level | Multi-layer with write-through |
| Request Optimization | Pagination | Rate limiting + caching |

---

## Recommendations

### For POV Implementation

1. **Consider Adding Rate Limiting:**
   - Implement rate limiting to prevent API throttling
   - Use a similar approach to Asguard's implementation

2. **Improve Error Handling:**
   - Add more specific exception handling
   - Implement better error recovery mechanisms

3. **Enhance Caching:**
   - Consider implementing a multi-layer caching system
   - Add automatic cache cleanup mechanisms

4. **Add Resource Management:**
   - Implement proper cleanup functions
   - Ensure session is properly closed when done

### For Asguard Implementation

1. **Expand Feature Set:**
   - Add support for more movie discovery endpoints
   - Implement anime-specific functions
   - Add list management features

2. **Optimize Connection Pooling:**
   - Consider increasing pool size for high-traffic scenarios
   - Implement connection pooling for list operations

3. **Add More Caching Options:**
   - Implement variable cache durations based on content type
   - Add support for longer-term caching of stable data

4. **Improve Error Recovery:**
   - Add more sophisticated retry logic
   - Implement fallback mechanisms for API failures

---

## Conclusion

Both POV and Asguard provide robust TMDB API implementations, but they take different approaches:

- **POV** offers a more comprehensive feature set with support for movies, TV shows, anime, people, and list management. It uses a dual-cache system and implements concurrent operations for better performance.

- **Asguard** focuses on reliability and performance with a multi-layer caching system, rate limiting, and comprehensive error handling. It also integrates with Trakt for cross-referencing.

The choice between the two depends on the specific needs of your Kodi addon:
- Choose POV if you need a wide range of features and comprehensive TMDB API coverage
- Choose Asguard if you prioritize reliability, performance, and better error handling

Both implementations can be improved by adopting best practices from each other, as outlined in the recommendations section.
