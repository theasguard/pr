# Trakt API Error Handling with raise_for_status() - Streamlined Approach

## Problem Description

The Asguard addon experiences intermittent issues with Trakt playback tracking where it stops tracking playback progress. The current error handling in `__call_trakt` is complex and has redundant urllib error handling when using requests library.

## POV Addon Approach Analysis

The POV addon uses a simpler approach with `raise_for_status()`:

```python
def call_trakt(path, params=None, data=None, with_auth=True, method=None, pagination=False, page=1):
    if isinstance(path, dict): return call_trakt(str(path.pop('path')), **path)
    else: path = str(path)
    headers = {'User-Agent': user_agent, 'trakt-api-key': V2_API_KEY, 'trkt-api-version': '2'}
    if with_auth and (token := get_setting('trakt.token')): headers['Authorization'] = 'Bearer %s' % token}
    try:
        response = session.request(
            'post' if data is not None else method or 'get',
            path if path.startswith('http') else base_url % path,
            params=None if data is not None else params,
            json=data if data else None,
            headers=headers,
            timeout=timeout
        )
        result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
        if not response.ok: response.raise_for_status()
        if (sort_by := response.headers.get('X-Sort-By')) and (sort_how := response.headers.get('X-Sort-How')):
            if sort_how in ('asc',) and sort_by in ('added', 'released'):
                if isinstance(result, list) and get_setting('trakt.reverse') == 'true': result.reverse()
        if pagination: return result, int(response.headers.get('X-Pagination-Page-Count', page))
        return result
    except requests.RequestException as e:
        logger('trakt error', str(e))
```

Key advantages of this approach:
1. Simpler error handling with `raise_for_status()`
2. Centralized exception handling
3. Cleaner code flow
4. Better separation of concerns
5. No redundant urllib error handling

## Proposed Solution for Asguard - Streamlined Approach

### Modified __call_trakt Method

Here's a cleaner, more streamlined version of the Asguard `__call_trakt` method that follows the POV approach more closely:

```python
def __call_trakt(self, url: str, method: str = None, data: Any = None, params: dict = None, auth: bool = True, cache_limit: float = .25, cached: bool = True) -> Union[str, list, dict, Any]:
    res_headers = {}
    if not cached: cache_limit = 0
    if self.offline:
        db_cache_limit = int(time.time()) / 60 / 60
    else:
        if cache_limit > 8:
            db_cache_limit = cache_limit
        else:
            db_cache_limit = 8
    json_data = json.dumps(data) if data else None
    logger.log('***Trakt Call: %s, data: %s cache_limit: %s cached: %s' % (url, json_data, cache_limit, cached), log_utils.LOGDEBUG)

    headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
    full_url = '%s%s%s' % (self.protocol, BASE_URL, url)
    if params: 
        full_url = full_url + '?' + urllib_parse.urlencode(params)

    db_connection = self.__get_db_connection()
    created, cached_headers, cached_result = db_connection.get_cached_url(full_url, json_data, db_cache_limit)
    if cached_result and (self.offline or (time.time() - created) < (60 * 60 * cache_limit)):
        result = cached_result
        res_headers = dict(cached_headers)
        logger.log('***Using cached result for: %s' % (full_url), log_utils.LOGDEBUG)
    else:
        auth_retry = False
        while True:
            try:
                if auth: 
                    headers.update({'Authorization': 'Bearer %s' % (self.token)})
                logger.log('***Trakt Call: %s, header: %s, data: %s cache_limit: %s cached: %s' % (full_url, headers, json_data, cache_limit, cached), log_utils.LOGDEBUG)
                req_method = 'POST' if json_data is not None else (method.upper() if method else 'GET')

                # Make the request using requests library
                r = session.request(req_method, full_url, headers=headers, json=data, params=None if data else params, timeout=self.timeout)

                # Use raise_for_status() to handle HTTP errors
                r.raise_for_status()

                # If we get here, the request was successful
                result = r.text
                logger.log('***Trakt Response: %s' % (result), log_utils.LOGDEBUG)
                res_headers = dict(r.headers)
                db_connection.cache_url(full_url, endpoint, result, json_data, list(r.headers.items()))
                break

            except requests.exceptions.HTTPError as e:
                # Handle HTTP errors with raise_for_status()
                status = e.response.status_code

                # Preserve legacy device auth polling semantics
                if full_url.endswith('/oauth/device/token'):
                    raise TraktAuthError('Device auth error: %s' % status)
                elif full_url.endswith('/oauth/token'):
                    raise TraktAuthError('Token error: %s' % status)

                # Handle temporary errors
                if status in TEMP_ERRORS:
                    if cached_result:
                        result = cached_result
                        res_headers = dict(cached_headers)
                        logger.log('Temporary Trakt Error (%s). Using Cached Page Instead.' % (status), log_utils.LOGWARNING)
                        break
                    else:
                        raise TransientTraktError('Temporary Trakt Error: HTTP %s' % status)

                # Handle authentication errors
                elif status in (401, 405):
                    # Check if profile is private
                    if e.response.headers.get('X-POV-Private-User') == 'true':
                        raise TraktAuthError('Object is No Longer Available (%s)' % (status))

                    # Handle auth failure
                    if auth_retry or full_url.endswith('/oauth/token'):
                        self.token = None
                        kodi.set_setting('trakt_oauth_token', '')
                        kodi.set_setting('trakt_refresh_token', '')
                        kodi.notify(msg='Trakt authentication failed. Please re-authenticate.', duration=5000)
                        raise TraktAuthError('Trakt Call Authentication Failed (%s)' % (status))

                    # Try to refresh token
                    try:
                        refresh_token = kodi.get_setting('trakt_refresh_token')
                        if not refresh_token:
                            logger.log('No refresh token available, private user check required', log_utils.LOGERROR)
                            kodi.notify(msg='Trakt authentication expired. Please re-authenticate.', duration=5000)
                            raise TraktAuthError('No refresh token available')

                        result = self.refresh_token(refresh_token)
                        if not result or 'access_token' not in result or 'refresh_token' not in result:
                            logger.log('Token refresh failed, re-authentication required', log_utils.LOGERROR)
                            kodi.notify(msg='Trakt token refresh failed. Please re-authenticate.', duration=5000)
                            raise TraktAuthError('Token refresh failed')

                        self.token = result['access_token']
                        kodi.set_setting('trakt_oauth_token', result['access_token'])
                        kodi.set_setting('trakt_refresh_token', result['refresh_token'])
                        auth_retry = True
                        continue
                    except Exception as refresh_error:
                        logger.log('Token refresh exception: %s' % str(refresh_error), log_utils.LOGERROR)
                        kodi.notify(msg='Trakt authentication error. Please re-authenticate.', duration=5000)
                        raise TraktAuthError('Token refresh exception: %s' % str(refresh_error))

                # Handle not found errors
                elif status == 404:
                    raise TraktNotFoundError('Object Not Found (%s): %s' % (status, full_url))

                # Handle other errors
                else:
                    raise TraktError('Trakt Error: HTTP %s' % status)

            except requests.exceptions.RequestException as e:
                # Handle all other requests exceptions (connection, timeout, etc.)
                if cached_result:
                    result = cached_result
                    res_headers = dict(cached_headers)
                    logger.log('Temporary Trakt Error (%s). Using Cached Page Instead.' % (str(e)), log_utils.LOGWARNING)
                    break
                else:
                    raise TransientTraktError('Temporary Trakt Error: ' + str(e))

            except Exception as e:
                logger.log('Unexpected error: {}'.format(e), log_utils.LOGERROR)
                raise

    try:
        js_data = utils.json_loads_as_str(result)
        if 'x-sort-by' in res_headers and 'x-sort-how' in res_headers:
            js_data = utils2.sort_list(res_headers['x-sort-by'], res_headers['x-sort-how'], js_data)
    except ValueError:
        js_data = ''
        if result:
            logger.log('Invalid JSON Trakt API Response: %s - |%s|' % (full_url, js_data), log_utils.LOGERROR)

    return js_data
```

## Key Changes

1. **Removed Redundant urllib Error Handling**: Since we're using the requests library, we no longer need the urllib error handling code.

2. **Simplified Exception Handling**: All requests-related exceptions are now handled through `requests.exceptions.RequestException`, which is the base class for all requests exceptions.

3. **Use raise_for_status()**: Added `r.raise_for_status()` to automatically raise an exception for HTTP error status codes (4xx, 5xx).

4. **Centralized HTTP Error Handling**: All HTTP errors are now handled in a single `except requests.exceptions.HTTPError` block, making the code cleaner and easier to maintain.

5. **Improved Token Refresh**: Enhanced the token refresh logic with better error handling and user notifications.

6. **Cleaner Code Flow**: The code now follows a more logical flow with clearer separation of concerns.

7. **Maintained Caching Functionality**: Preserved the caching functionality that's specific to Asguard.

8. **Reduced Code Duplication**: Eliminated redundant error handling code that was duplicated for urllib and requests.

## Benefits of This Approach

1. **Simpler Code**: The code is now simpler and easier to understand, with less duplication.

2. **Better Error Handling**: Using `raise_for_status()` provides more consistent error handling across all HTTP requests.

3. **More Maintainable**: With less code duplication and clearer error handling, the code is easier to maintain and debug.

4. **Follows Best Practices**: This approach follows the best practices for using the requests library.

5. **Preserves Functionality**: All existing functionality is preserved while improving the code structure.
