# TMDB API Implementation Summary

## Overview
This document summarizes the implementation of anime-specific functions and list management features from the POV addon into the Asguard (SALTS Fork) addon's TMDB API module.

## Changes Made

### 1. Constants Added

Two new constants were added to support the new features:

```python
TMDB_API_V4_URL = 'https://api.themoviedb.org/4'
ANIME_KEYWORD_ID = 210024  # TMDB keyword ID for anime content
```

### 2. Anime-Specific Functions

Eight new functions were added to support anime content discovery:

#### Anime Movies
- **get_anime_movies_popular(page=1)**: Get popular anime movies sorted by popularity
- **get_anime_movies_latest_releases(page=1)**: Get latest anime movie releases from the past 6 months
- **get_anime_movies_by_genre(genre_id, page=1)**: Get anime movies filtered by genre
- **get_anime_movies_by_year(year, page=1)**: Get anime movies filtered by release year

#### Anime TV Shows
- **get_anime_tv_popular(page=1)**: Get popular anime TV shows sorted by popularity
- **get_anime_tv_premieres(page=1)**: Get recent anime TV show premieres from the past 6 months
- **get_anime_tv_by_genre(genre_id, page=1)**: Get anime TV shows filtered by genre
- **get_anime_tv_by_year(year, page=1)**: Get anime TV shows filtered by first air date year

All anime functions:
- Use the TMDB keyword ID 210024 for anime filtering
- Maintain Asguard's existing caching and rate limiting
- Follow Asguard's error handling patterns
- Include comprehensive docstrings

### 3. List Management Functions (TMDB API v4)

Complete list management functionality was added using TMDB API v4 with bearer token authentication:

#### Helper Functions
- **_get_v4_headers()**: Generate authentication headers for API v4 requests
- **_make_v4_request(url, method, params, data)**: Generic function for making API v4 requests

#### Watchlist Management
- **get_user_watchlist(mediatype, page)**: Retrieve user's watchlist
- **add_to_watchlist(media_type, media_id, watchlist)**: Add or remove items from watchlist

#### Favorites Management
- **get_user_favorites(mediatype, page)**: Retrieve user's favorites
- **add_to_favorites(media_type, media_id, favorite)**: Add or remove items from favorites

#### Custom List Management
- **get_user_lists(page)**: Get user's custom lists
- **get_list_details(list_id)**: Get details of a specific list
- **create_list(list_name, description, public)**: Create a new list
- **add_items_to_list(list_id, items)**: Add items to a list
- **remove_items_from_list(list_id, items)**: Remove items from a list
- **update_list(list_id, name, description, public)**: Update list properties
- **clear_list(list_id)**: Clear all items from a list
- **delete_list(list_id)**: Delete a list
- **check_item_status(list_id, media_type, media_id)**: Check if an item is in a list

## Integration with Asguard Architecture

The implementation maintains consistency with Asguard's existing architecture:

1. **Caching**: All new functions use Asguard's existing caching system (_rate_limited_request)
2. **Rate Limiting**: Requests respect the 150ms rate limit delay
3. **Error Handling**: Comprehensive error handling with logging
4. **Session Management**: Uses the existing session pooling
5. **Settings Integration**: Uses kodi.get_setting() for configuration

## Configuration Requirements

To use the list management features, users need to configure:

1. **TMDB API Key**: Required for all functions
   - Setting: `tmdb_key`

2. **TMDB Bearer Token**: Required for list management (API v4)
   - Setting: `tmdb_bearer_token`

3. **TMDB Account ID**: Required for user-specific list operations
   - Setting: `tmdb_account_id`

## Usage Examples

### Anime Functions

```python
# Get popular anime movies
anime_movies = get_anime_movies_popular(page=1)

# Get latest anime releases
latest_anime = get_anime_movies_latest_releases(page=1)

# Get anime by genre
action_anime = get_anime_movies_by_genre(genre_id=28, page=1)

# Get anime by year
anime_2023 = get_anime_movies_by_year(year=2023, page=1)
```

### List Management Functions

```python
# Get user's watchlist
watchlist = get_user_watchlist(mediatype='movie', page=1)

# Add item to watchlist
success = add_to_watchlist(media_type='movie', media_id=12345, watchlist=True)

# Create a new list
list_id = create_list('My Favorites', 'My favorite movies', public=True)

# Add items to list
items = [
    {'media_type': 'movie', 'media_id': 12345},
    {'media_type': 'tv', 'media_id': 67890}
]
add_items_to_list(list_id, items)
```

## Notes

1. All anime functions use TMDB's discover endpoints with the anime keyword filter (210024)
2. List management functions require TMDB API v4 authentication
3. The implementation follows Asguard's coding conventions and patterns
4. All functions include comprehensive docstrings for documentation
5. Error handling is consistent with Asguard's existing approach

## Future Enhancements

Potential future improvements could include:

1. Import functionality from Trakt and MDbList (similar to POV)
2. Batch operations for list management
3. Advanced filtering options for anime content
4. Support for custom date ranges in anime functions
5. Caching optimization for list operations
